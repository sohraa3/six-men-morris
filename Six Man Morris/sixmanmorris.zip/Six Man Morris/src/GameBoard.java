/*
 * This class draws all of the graphics onto the window.
 * Draws the default game board and the 2 player pieces on startup.
 * Updates the game board whenever the user clicks on one of the spaces.
 * Uses an array of colors to determine the color of each space. Each space on the board corresponds to an index in the array.
 */
import javax.swing.*;
import java.awt.*;

public class GameBoard extends JPanel{
	
	//This array sores the colors of the dots
	Color[] colors = new Color[16];
	public GameBoard(Color[] colors){
		for(int i=0;i<16;i++){
			this.colors[i] = colors[i];
		}
	}
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		//Set line thickness and color
		g2.setStroke(new BasicStroke(5));
		g2.setColor(Color.BLACK);
		
		g2.drawRect(100, 100, 400, 400);//Outside square
		g2.drawRect(200,200,200,200);//Inner square
		
		g2.drawLine(300, 100, 300, 200);//Top line
		g2.drawLine(300, 400, 300, 500);//Bottom line
		g2.drawLine(100, 300, 200, 300);//Left line
		g2.drawLine(400, 300, 500, 300);//Right line
		
		//Draw the dots on the board
		//The colors of each dot corresponds to an index in the color array
		g2.setColor(colors[0]);
		g2.fillOval(90,90,20,20);
		g2.setColor(colors[1]);
		g2.fillOval(290,90,20,20);
		g2.setColor(colors[2]);
		g2.fillOval(490,90,20,20);
		
		g2.setColor(colors[3]);
		g2.fillOval(190,190,20,20);
		g2.setColor(colors[4]);
		g2.fillOval(290,190,20,20);
		g2.setColor(colors[5]);
		g2.fillOval(390,190,20,20);
		
		g2.setColor(colors[6]);
		g2.fillOval(90,290,20,20);
		g2.setColor(colors[7]);
		g2.fillOval(190,290,20,20);
		g2.setColor(colors[8]);
		g2.fillOval(390,290,20,20);
		g2.setColor(colors[9]);
		g2.fillOval(490,290,20,20);
		
		g2.setColor(colors[10]);
		g2.fillOval(190,390,20,20);
		g2.setColor(colors[11]);
		g2.fillOval(290,390,20,20);
		g2.setColor(colors[12]);
		g2.fillOval(390,390,20,20);
		
		g2.setColor(colors[13]);
		g2.fillOval(90,490,20,20);
		g2.setColor(colors[14]);
		g2.fillOval(290,490,20,20);
		g2.setColor(colors[15]);
		g2.fillOval(490,490,20,20);
		
		//Draw the blue and red player discs at the top
		g2.setColor(Color.BLUE);
		g2.fillOval(200, 20, 50, 50);
		g2.setColor(Color.RED);
		g2.fillOval(350, 20, 50, 50);
	  }
}
