import java.awt.Color;
import java.util.Random;

//This class decides which moves the AI will make
public class AIControl {
	Random r;//Used for randomly choosing spaces on the board
	public AIControl(){
		r = new Random();
	}
	//Allows the AI to place pieces
	public int placePiece(Color[] board){
		while(true){
			int x = r.nextInt(16);//Pick a spot on the board and return that spot if it's empty
			if(board[x] == Color.BLACK){
				return x;
			}
		}
	}
	//Allows the AI to remove pieces
	public int removePiece(Color[] board, Color playerPiece){
		while(true){
			int x = r.nextInt(16);//Pick a spot on the board and return that spot if it has the other player's piece
			if(board[x] == playerPiece){
				return x;
			}
		}
	}
	//Allows the AI to pick one of their pieces to move
	public int pickPiece(Color[] board, Color aiPiece, GameLogic logic){
		while(true){
			int x = r.nextInt(16);//Pick a spot on the board and return that spot if it has the AI's piece and it can be moved
			if(board[x] == aiPiece && logic.isMoveable(x)){
				return x;
			}
		}
	}
	//Allows the AI to move their piece
	public int movePiece(Color[] board, Color aiPiece, GameLogic logic, int currentSpot){
		while(true){
			int x = r.nextInt(16);//Pick a spot on the board and return that spot if it the AI can move it's piece there
			if(logic.validMove(currentSpot, x)){
				return x;
			}
		}
	}
}
