/*
 * This class handles the logic of the game (rules).
 * It keeps track of the number of piece each player has placed and the maximum number of pieces a player can place.
 * It has functions that look for mills and a function that determines if the current board is valid before starting a game.
 * It has 2 more functions that return the number of pieces each player has.
 */
import java.awt.Color;

public class GameLogic {
	private static Color[] points = new Color[16];
	private static int bluePoints;
	private static int redPoints;
	private static int maxBlue;
	private static int maxRed;
	private static int bluePlaced = 0;//Integer that keeps track of how many pieces blue has placed
	private static int redPlaced = 0;//Integer that keeps track of how many pieces red has placed
	int bluePieces = 6;//Integer that keeps track of how many pieces blue has remaining
	int redPieces = 6;//Integer that keeps track of how many pieces red has remaining
	
	//Initialise point values
	public GameLogic(){
		bluePoints = 0;
		redPoints = 0;
		maxBlue = 6;
		maxRed = 6;
	}
	//Public method that updates the color array for the game logic
	public void updatePoints(Color[] newpoints){
		for(int i=0; i<16; i++){
			points[i] = newpoints[i];
		}
	}
	//This method is used to increment the bluePlaced and redPlaced counters whenever a player places a piece
	public void addPiece(Color player){
		if(player == Color.BLUE){
			bluePlaced++;
		}
		else{
			redPlaced++;
		}
	}
	//Method that resets bluePlaced and redPlaced when starting a new game
	public void resetPlaced(){
		bluePlaced = 0;
		redPlaced = 0;
	}
	//Method that allows the user to the set bluePlace and redPlaced values
	public void setPlaced(int blue, int red){
		bluePlaced = blue;
		redPlaced = red;
	}
	//Function that counts the points by iterating through the color array
	public static void countPoints(){
		//Re-initialise the points
		bluePoints = 0;
		redPoints = 0;
		for(int i=0; i<16;i++){
			if(points[i]==Color.BLUE){
				bluePoints++;
			}
			else if(points[i]==Color.RED){
				redPoints++;
			}
		}
	}
	//Method that checks the status of the game and decides when to switch game phases
	public int checkPhase(){
		if(bluePlaced>=6 && redPlaced>=6){//If both players have placed their 6 pieces, move to the second phase
			return 2;
		}
		return 1;
	}
	//These functions check their respective rows for 3-in-a-row
	public boolean checkRow1(){
		if((points[0]==points[1]) && (points[0]==points[2]) && points[0]!=Color.BLACK && points[1]!=Color.BLACK && points[2]!=Color.BLACK){
			return true;
		}
		return false;
	}
	public boolean checkRow2(){
		if((points[3]==points[4]) && (points[3]==points[5])&& points[3]!=Color.BLACK && points[4]!=Color.BLACK && points[5]!=Color.BLACK){
			return true;
		}
		return false;
	}
	public boolean checkRow3(){
		if((points[10]==points[11]) && (points[10]==points[12])&& points[10]!=Color.BLACK && points[11]!=Color.BLACK && points[12]!=Color.BLACK){
			return true;
		}
		return false;
	}
	public boolean checkRow4(){
		if((points[13]==points[14]) && (points[13]==points[15])&& points[13]!=Color.BLACK && points[14]!=Color.BLACK && points[15]!=Color.BLACK){
			return true;
		}
		return false;
	}
	//These functions check their respective columns for 3-in-a-row
	public boolean checkCol1(){
		if((points[0]==points[6]) && (points[0]==points[13])&& points[0]!=Color.BLACK && points[6]!=Color.BLACK && points[13]!=Color.BLACK){
			return true;
		}
		return false;
	}
	public boolean checkCol2(){
		if((points[3]==points[7]) && (points[3]==points[10])&& points[3]!=Color.BLACK && points[7]!=Color.BLACK && points[10]!=Color.BLACK){
			return true;
		}
		return false;
	}
	public boolean checkCol3(){
		if((points[5]==points[8]) && (points[5]==points[12])&& points[5]!=Color.BLACK && points[8]!=Color.BLACK && points[12]!=Color.BLACK){
			return true;
		}
		return false;
	}
	public boolean checkCol4(){
		if((points[2]==points[9]) && (points[2]==points[15])&& points[2]!=Color.BLACK && points[9]!=Color.BLACK && points[15]!=Color.BLACK){
			return true;
		}
		return false;
	}
	//Method that checks if a piece can be moved
	public boolean isMoveable(int i){
		if(i==0 && points[1]!=Color.BLACK && points[6]!=Color.BLACK){//If moving piece i, check positions 1 and 6 for open spaces
			return false;//Return false if there's no open space
		}
		else if(i==1 && points[0]!=Color.BLACK && points[2]!=Color.BLACK && points[4]!=Color.BLACK){//If moving piece i, check adjacent spaces or an open space
			return false;//Return false if there's no open space
		}
		else if(i==2 && points[1]!=Color.BLACK && points[9]!=Color.BLACK){//If moving piece i, check adjacent spaces or an open space
			return false;//Return false if there's no open space
		}
		else if(i==3 && points[4]!=Color.BLACK && points[7]!=Color.BLACK){//If moving piece i, check adjacent spaces or an open space
			return false;//Return false if there's no open space
		}
		else if(i==4 && points[1]!=Color.BLACK && points[3]!=Color.BLACK && points[5]!=Color.BLACK){//If moving piece i, check adjacent spaces or an open space
			return false;//Return false if there's no open space
		}
		else if(i==5 && points[4]!=Color.BLACK && points[8]!=Color.BLACK){//If moving piece i, check adjacent spaces or an open space
			return false;//Return false if there's no open space
		}
		else if(i==6 && points[0]!=Color.BLACK && points[7]!=Color.BLACK && points[13]!=Color.BLACK){//If moving piece i, check adjacent spaces or an open space
			return false;//Return false if there's no open space
		}
		else if(i==7 && points[3]!=Color.BLACK && points[6]!=Color.BLACK && points[10]!=Color.BLACK){//If moving piece i, check adjacent spaces or an open space
			return false;//Return false if there's no open space
		}
		else if(i==8 && points[5]!=Color.BLACK && points[9]!=Color.BLACK && points[12]!=Color.BLACK){//If moving piece i, check adjacent spaces or an open space
			return false;//Return false if there's no open space
		}
		else if(i==9 && points[2]!=Color.BLACK && points[8]!=Color.BLACK && points[15]!=Color.BLACK){//If moving piece i, check adjacent spaces or an open space
			return false;//Return false if there's no open space
		}
		else if(i==10 && points[7]!=Color.BLACK && points[11]!=Color.BLACK){//If moving piece i, check adjacent spaces or an open space
			return false;//Return false if there's no open space
		}
		else if(i==11 && points[10]!=Color.BLACK && points[12]!=Color.BLACK && points[14]!=Color.BLACK){//If moving piece i, check adjacent spaces or an open space
			return false;//Return false if there's no open space
		}
		else if(i==12 && points[8]!=Color.BLACK && points[11]!=Color.BLACK){//If moving piece i, check adjacent spaces or an open space
			return false;//Return false if there's no open space
		}
		else if(i==13 && points[6]!=Color.BLACK && points[14]!=Color.BLACK){//If moving piece i, check adjacent spaces or an open space
			return false;//Return false if there's no open space
		}
		else if(i==14 && points[13]!=Color.BLACK && points[11]!=Color.BLACK && points[15]!=Color.BLACK){//If moving piece i, check adjacent spaces or an open space
			return false;//Return false if there's no open space
		}
		else if(i==15 && points[9]!=Color.BLACK && points[14]!=Color.BLACK){//If moving piece i, check adjacent spaces or an open space
			return false;//Return false if there's no open space
		}
		return true;//Return true otherwise
	}
	//Method that checks if 2 spaces are adjacent and if it's possible to move to from one a to b
	public boolean validMove(int a, int b){
		if(a==b){return false;}//You can't move to the same spot
		
		else if(a==0){//Check that that b is adjacent to a and that it's empty
			if(b==1 && points[1]==Color.BLACK){return true;}
			else if(b==6 && points[6]==Color.BLACK){return true;}
		}
		else if(a==1){//Check that that b is adjacent to a and that it's empty
			if(b==0 && points[0]==Color.BLACK){return true;}
			else if(b==2 && points[2]==Color.BLACK){return true;}
			else if(b==4 && points[4]==Color.BLACK){return true;}
		}
		else if(a==2){//Check that that b is adjacent to a and that it's empty
			if(b==1 && points[1]==Color.BLACK){return true;}
			else if(b==9 && points[9]==Color.BLACK){return true;}
		}
		else if(a==3){//Check that that b is adjacent to a and that it's empty
			if(b==4 && points[4]==Color.BLACK){return true;}
			else if(b==7 && points[7]==Color.BLACK){return true;}
		}
		else if(a==4){//Check that that b is adjacent to a and that it's empty
			if(b==1 && points[1]==Color.BLACK){return true;}
			else if(b==3 && points[3]==Color.BLACK){return true;}
			else if(b==5 && points[5]==Color.BLACK){return true;}
		}
		else if(a==5){//Check that that b is adjacent to a and that it's empty
			if(b==4 && points[4]==Color.BLACK){return true;}
			else if(b==8 && points[8]==Color.BLACK){return true;}
		}
		else if(a==6){//Check that that b is adjacent to a and that it's empty
			if(b==0 && points[0]==Color.BLACK){return true;}
			else if(b==7 && points[7]==Color.BLACK){return true;}
			else if(b==13 && points[13]==Color.BLACK){return true;}
		}
		else if(a==7){//Check that that b is adjacent to a and that it's empty
			if(b==3 && points[3]==Color.BLACK){return true;}
			else if(b==6 && points[6]==Color.BLACK){return true;}
			else if(b==10 && points[10]==Color.BLACK){return true;}
		}
		else if(a==8){//Check that that b is adjacent to a and that it's empty
			if(b==12 && points[12]==Color.BLACK){return true;}
			else if(b==9 && points[9]==Color.BLACK){return true;}
			else if(b==5 && points[5]==Color.BLACK){return true;}
		}
		else if(a==9){//Check that that b is adjacent to a and that it's empty
			if(b==2 && points[2]==Color.BLACK){return true;}
			else if(b==8 && points[8]==Color.BLACK){return true;}
			else if(b==15 && points[15]==Color.BLACK){return true;}
		}
		else if(a==10){//Check that that b is adjacent to a and that it's empty
			if(b==7 && points[7]==Color.BLACK){return true;}
			else if(b==11 && points[11]==Color.BLACK){return true;}
		}
		else if(a==11){//Check that that b is adjacent to a and that it's empty
			if(b==10 && points[10]==Color.BLACK){return true;}
			else if(b==12 && points[12]==Color.BLACK){return true;}
			else if(b==14 && points[14]==Color.BLACK){return true;}
		}
		else if(a==12){//Check that that b is adjacent to a and that it's empty
			if(b==8 && points[8]==Color.BLACK){return true;}
			else if(b==11 && points[11]==Color.BLACK){return true;}
		}
		else if(a==13){//Check that that b is adjacent to a and that it's empty
			if(b==6 && points[6]==Color.BLACK){return true;}
			else if(b==14 && points[14]==Color.BLACK){return true;}
		}
		else if(a==14){//Check that that b is adjacent to a and that it's empty
			if(b==11 && points[11]==Color.BLACK){return true;}
			else if(b==13 && points[13]==Color.BLACK){return true;}
			else if(b==15 && points[15]==Color.BLACK){return true;}
		}
		else if(a==15){//Check that that b is adjacent to a and that it's empty
			if(b==9 && points[9]==Color.BLACK){return true;}
			else if(b==14 && points[14]==Color.BLACK){return true;}
		}
		return false;
	}
	//Function that sees if the current board state is valid
	public static boolean isValid(){
		if(bluePoints>maxBlue){return false;}
		else if(redPoints>maxRed){return false;}
		return true;
	}
	//Function that returns the number of blue points
	public static int getBlue(){
		return bluePoints;
	}
	//Function that returns the number of red points
	public static int getRed(){
		return redPoints;
	}
}
