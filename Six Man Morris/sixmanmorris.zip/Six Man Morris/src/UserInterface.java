/*
 * This is the main class the controls the game. It uses the functions of the other 2 classes.
 * It sets up the main JFrame as well as all of the JLabels and JButtons.
 * Uses GameBoard.java to create the game board and adds it to the JFrame.
 * Has functions that track mouse clicks and responds depending on its coordinates.
 * Has an array of colors that is updated by mouse inputs. This array is passed to GameBoard.java so it can update the game board
 * when necessary.
 * Has 2 JButtons: one to start a new game by resetting the board and randomly choosing a player, and another is to
 * start a game in progress by first validating the current board (using GameLogic.java) then allowing the players to play using the current board.
 * 
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class UserInterface extends JFrame {
	static Color[] colors = new Color[16];//Array of colors
	static GameBoard board = new GameBoard(colors);//Create a new GameBoard object
	static GameLogic logic = new GameLogic();//Create a new GameLogic object
	static AIControl ai = new AIControl();
	static Color player = Color.BLACK;//The current color which represents the current player. Default is black.
	static Color aiColor = Color.BLACK;//The current color which represents the AI
	static JLabel status = new JLabel();//Label that displays the current player
	static JButton newGame = new JButton("vs. Player");//Button to start a new game
	static JButton newGameAI = new JButton("vs. AI");
	static JButton start = new JButton("Start vs. Player");//Button to start a game once it is set up
	static JButton startAI = new JButton("Start vs. AI");//Buttons to start a game once it is set up against the AI
	static JButton save = new JButton("Save");//Button to save an unfinished game
	static JButton load = new JButton("Load");//Button to load a saved unfinished game
	static JLabel playState = new JLabel();//This label displays whether or not the current board is valid, if a move is invalid, and the current play state (In progress, draw, win, etc.)
	static JLabel blueScore = new JLabel();//Label that displays the blue player's score
	static JLabel redScore = new JLabel();//Label that displays the red player's score
	static boolean playGame = false;//Boolean that determines if a game is being played
	static boolean playAI = false;//Boolean that determines if the player is facing the AI or not
	static int phase = 0;//Integer that determines the current phase of the game
	static int currentPiece;//Integer that keeps track of which piece is being moved
	
	
	public UserInterface(){
		super("Six-man Morris");
		setSize(760,700);
		setVisible(true);
	}
	public static void main(String args[]) {
		//Initialise the color array by filling it with the color Black
		for(int i=0; i<16; i++){
			colors[i] = Color.BLACK;
		}
		UserInterface main = new UserInterface();
		logic.updatePoints(colors);
		main.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		main.add(setButtons(), BorderLayout.PAGE_END);
		main.add(setScorePane(),BorderLayout.NORTH);
		main.add(board);
		//Create a new class the handles mouse events
		Handlerclass handler = new Handlerclass();
		board.addMouseListener(handler);
		status.setFont(new Font("Serif",Font.BOLD, 25));
		setScores();
		newGame.addActionListener(handler);
		newGameAI.addActionListener(handler);
		start.addActionListener(handler);
		startAI.addActionListener(handler);
		save.addActionListener(handler);
		load.addActionListener(handler);
	 }
	private static JPanel setButtons(){//Method that adds the buttons to a JPanel
		JPanel buttonPane = new JPanel();//Create a JPanel that holds buttons and labels
		buttonPane.setLayout(new BoxLayout(buttonPane, BoxLayout.LINE_AXIS));//Set the layout of the panel
		buttonPane.add(Box.createHorizontalGlue());
		buttonPane.add(status);
		buttonPane.add(Box.createRigidArea(new Dimension(0, 0)));
		buttonPane.add(newGame);
		buttonPane.add(Box.createRigidArea(new Dimension(0, 0)));
		buttonPane.add(newGameAI);
		buttonPane.add(Box.createRigidArea(new Dimension(0, 0)));
		buttonPane.add(start);
		buttonPane.add(Box.createRigidArea(new Dimension(0, 0)));
		buttonPane.add(startAI);
		buttonPane.add(Box.createRigidArea(new Dimension(0, 0)));
		buttonPane.add(save);
		buttonPane.add(Box.createRigidArea(new Dimension(0, 0)));
		buttonPane.add(load);
		
		
		return buttonPane;
	}
	private static JPanel setScorePane(){//Method that adds score information to a JPanel
		JPanel scorePane = new JPanel();
		scorePane.setLayout(new BoxLayout(scorePane, BoxLayout.Y_AXIS));//Set the layout of the panel
		scorePane.add(Box.createVerticalGlue());
		scorePane.add(blueScore);
		scorePane.add(redScore);
		scorePane.add(playState);
		return scorePane;
	}
	private static void setScores(){//Method that sets up the score labels
		blueScore.setFont(new Font("Serif",Font.BOLD, 25));
		blueScore.setForeground(Color.BLUE);
		blueScore.setText("Blue Score: ");
		redScore.setFont(new Font("Serif",Font.BOLD, 25));
		redScore.setForeground(Color.RED);
		redScore.setText("Red Score: ");
		playState.setFont(new Font("Serif",Font.BOLD, 25));
		playState.setForeground(Color.BLUE);
	}
	//The UserInterface uses this class to handle mouse events (clicks)
	private static class Handlerclass implements MouseListener, MouseMotionListener, ActionListener{
		public void mouseClicked(MouseEvent e){
			System.out.println(e.getX() + "   " + e.getY());//Print the current mouse coordinates. Used for debugging
			if((e.getX()>=200)&&(e.getX()<=250)&&(e.getY()>=20)&&(e.getY()<=70)&&(playGame==false)){//If the player clicks the blue disc while a game isn't in progress
				player = Color.BLUE;//Change the current player to Blue
				status.setForeground(Color.BLUE);
				status.setText("Current player: BLUE");
				playState.setText("");
			}
			else if((e.getX()>=350)&&(e.getX()<=400)&&(e.getY()>=20)&&(e.getY()<=70)&&(playGame==false)){//If the player clicks the red disc while a game isn't in progress
				player = Color.RED;//Change the current player to Red
				status.setForeground(Color.RED);
				status.setText("Current player: RED");
				playState.setText("");
			}
			//The next few if statements are ran whenever the players clicks on one of the spaces on the board
			//The space they clicked on changes to the current player's color
			else if((e.getX()>=90)&&(e.getX()<=110)&&(e.getY()>=90)&&(e.getY()<=110)){
				if(phase==1){//If the current phase is 1: Placing pieces
					if(colors[0]==Color.BLACK){//Can only place pieces on blank spaces
						colors[0] = player;//Update the color array
						board.colors = colors;
						board.repaint();//Repaint the board with the new colors
						playState.setText("Game In Progress: Placing pieces");
						//Switch to the next player and increment their respective Placed counters
						logic.addPiece(player);
						logic.updatePoints(colors);
						if(player == Color.BLUE){
							if(logic.checkRow1() || logic.checkCol1()){//If the player has formed a mill, move to the temporary 3rd phase: milling
								phase = 3;
								playState.setText("Game In Progress: Mill");
							}
							else{
								if(playAI==true){
									phase = logic.checkPhase();
									if(phase==2){
										playState.setText("Game In Progress: Moving Pieces");
									}
									AITurn();
								}
								else{
									status.setForeground(Color.RED);
									status.setText("Current player: RED");
									player = Color.RED;
									phase = logic.checkPhase();
									if(phase==2){
										playState.setText("Game In Progress: Moving Pieces");
									}
								}
							}
							
							}
						else{
							if(logic.checkRow1() || logic.checkCol1()){//If the player has formed a mill, move to the temporary 3rd phase: milling
								phase = 3;
								playState.setText("Game In Progress: Mill");
							}
							else{//If the player hasn't formed a mill, then go to the next player's turn
								status.setForeground(Color.BLUE);
								status.setText("Current Player: BLUE");
								player = Color.BLUE;
								phase = logic.checkPhase();
								if(phase==2){
									playState.setText("Game In Progress: Moving Pieces");
								}
							}	
						}
					}
				}
				else if(phase==0){//If the current phase is 0: Setting up a game in progress
					colors[0] = player;//Update the color array
					board.colors = colors;
					board.repaint();//Repaint the board with the new colors
					playState.setText("");
				}
				else if(phase==2){//If the current phase is 2: Choosing pieces to move
					if(player==Color.BLUE && colors[0]==Color.BLUE && logic.isMoveable(0)){//If the current player selects their own piece
						currentPiece = 0;//Update the current piece being moved
						phase = 4;//Move to the temporary 4th phase: moving the piece
						playState.setText("Game In Progress: Moving Piece 0");
					}
					else if(player==Color.RED && colors[0]==Color.RED && logic.isMoveable(0)){//If the current player selects their own piece
						currentPiece = 0;//Update the current piece being moved
						phase = 4;//Move to the temporary 4th phase: moving the piece
						playState.setText("Game In Progress: Moving Piece 0");
					}
				}
				else if(phase==3){//If the current phase is 3: milling
					if(player==Color.BLUE){
						if(colors[0]!=Color.BLACK && colors[0]!=Color.BLUE){//Check to see if the space isn't empty or if it isn't occupied by your own piece
							colors[0]=Color.BLACK;//Remove the piece and replace it with a blank piece
							board.colors = colors;
							board.repaint();//Repaint the board with the new colors
							logic.updatePoints(colors);
							logic.redPieces--;//Decrement the number of pieces red has remaining
							if(playAI==true){
								phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
								if(phase==1){playState.setText("Game In Progress: Placing pieces");}
								else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
								AITurn();
							}
							else{
								status.setForeground(Color.RED);//Switch to the next player
								status.setText("Current player: RED");
								player = Color.RED;
								phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
								if(phase==1){playState.setText("Game In Progress: Placing pieces");}
								else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
								}	
							}
							
					}
					else if(player==Color.RED){
						if(colors[0]!=Color.BLACK && colors[0]!=Color.RED){//Check to see if the space isn't empty or if it isn't occupied by your own piece
							colors[0]=Color.BLACK;//Remove the piece and replace it with a blank piece
							board.colors = colors;
							board.repaint();//Repaint the board with the new colors
							logic.updatePoints(colors);
							logic.bluePieces--;//Decrement the number of pieces blue has remaining
							status.setForeground(Color.BLUE);//Switch to the next player
							status.setText("Current Player: BLUE");
							player = Color.BLUE;
							phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
							if(phase==1){playState.setText("Game In Progress: Placing pieces");}
							else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
						}
					}
				}
				else if(phase==4){//If the current phase is 4: Moving a piece
					if(logic.validMove(currentPiece, 0)){
						colors[0] = player;//Update the color arrays
						colors[currentPiece] = Color.BLACK;
						logic.updatePoints(colors);
						board.colors = colors;
						board.repaint();//Repaint the board
						if(logic.checkRow1() || logic.checkCol1()){//Check for a mill
							phase = 3;
							playState.setText("Game in Progress: Mill");
						}
						else if(playAI){
							phase = 2;
							AITurn();
						}
						else{//Switch to the next player and go back to phase 2
							if(player==Color.BLUE){
								player=Color.RED;
								status.setForeground(Color.RED);
								status.setText("Current Player: RED");
							}
							else{
								player=Color.BLUE;
								status.setForeground(Color.BLUE);
								status.setText("Current Player: BLUE");
							}
							phase = 2;
							playState.setText("Game In Progress: Moving Pieces");
						}
					}
				}
			}
			else if((e.getX()>=290)&&(e.getX()<=310)&&(e.getY()>=90)&&(e.getY()<=110)){
				if(phase==1){//If the current phase is 1: Placing pieces
					if(colors[1]==Color.BLACK){//Can only place pieces on blank spaces
						colors[1] = player;//Update the color array
						board.colors = colors;
						board.repaint();//Repaint the board with the new colors
						playState.setText("Game In Progress: Placing pieces");
						//Switch to the next player and increment their respective Placed counters
						logic.addPiece(player);
						logic.updatePoints(colors);
						if(player == Color.BLUE){
							if(logic.checkRow1()){//If the player has formed a mill, move to the temporary 3rd phase: milling
								phase = 3;
								playState.setText("Game In Progress: Mill");
							}
							else{
								if(playAI==true){
									phase = logic.checkPhase();
									if(phase==2){
										playState.setText("Game In Progress: Moving Pieces");
									}
									AITurn();
								}
								else{
									status.setForeground(Color.RED);
									status.setText("Current player: RED");
									player = Color.RED;
									phase = logic.checkPhase();
									if(phase==2){
										playState.setText("Game In Progress: Moving Pieces");
									}
								}
							}
							
							}
						else{
							if(logic.checkRow1()){//If the player has formed a mill, move to the temporary 3rd phase: milling
								phase = 3;
								playState.setText("Game In Progress: Mill");
							}
							else{//If the player hasn't formed a mill, then go to the next player's turn
								status.setForeground(Color.BLUE);
								status.setText("Current Player: BLUE");
								player = Color.BLUE;
								phase = logic.checkPhase();
								if(phase==2){
									playState.setText("Game In Progress: Moving Pieces");
								}
							}	
						}
					}
				}
				else if(phase==0){//If the current phase is 0: Setting up a game in progress
					colors[1] = player;//Update the color array
					board.colors = colors;
					board.repaint();//Repaint the board with the new colors
					playState.setText("");
				}
				else if(phase==2){//If the current phase is 2: Choosing pieces to move
					if(player==Color.BLUE && colors[1]==Color.BLUE && logic.isMoveable(1)){//If the current player selects their own piece
						currentPiece = 1;//Update the current piece being moved
						phase = 4;//Move to the temporary 4th phase: moving the piece
						playState.setText("Game In Progress: Moving Piece 1");
					}
					else if(player==Color.RED && colors[1]==Color.RED && logic.isMoveable(1)){//If the current player selects their own piece
						currentPiece = 1;//Update the current piece being moved
						phase = 4;//Move to the temporary 4th phase: moving the piece
						playState.setText("Game In Progress: Moving Piece 1");
					}
				}
				else if(phase==3){//If the current phase is 3: milling
					if(player==Color.BLUE){
						if(colors[1]!=Color.BLACK && colors[1]!=Color.BLUE){//Check to see if the space isn't empty or if it isn't occupied by your own piece
							colors[1]=Color.BLACK;//Remove the piece and replace it with a blank piece
							board.colors = colors;
							board.repaint();//Repaint the board with the new colors
							logic.updatePoints(colors);
							logic.redPieces--;//Decrement the number of pieces red has remaining
							if(playAI==true){
								phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
								if(phase==1){playState.setText("Game In Progress: Placing pieces");}
								else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
								AITurn();
							}
							else{
								status.setForeground(Color.RED);//Switch to the next player
								status.setText("Current player: RED");
								player = Color.RED;
								phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
								if(phase==1){playState.setText("Game In Progress: Placing pieces");}
								else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
								}	
							}
					}
					else if(player==Color.RED){
						if(colors[1]!=Color.BLACK && colors[1]!=Color.RED){//Check to see if the space isn't empty or if it isn't occupied by your own piece
							colors[1]=Color.BLACK;//Remove the piece and replace it with a blank piece
							board.colors = colors;
							board.repaint();//Repaint the board with the new colors
							logic.updatePoints(colors);
							logic.bluePieces--;//Decrement the number of pieces blue has remaining
							status.setForeground(Color.BLUE);//Switch to the next player
							status.setText("Current Player: BLUE");
							player = Color.BLUE;
							phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
							if(phase==1){playState.setText("Game In Progress: Placing pieces");}
							else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
						}
					}
				}
				else if(phase==4){//If the current phase is 4: Moving a piece
					if(logic.validMove(currentPiece, 1)){
						colors[1] = player;//Update the color arrays
						colors[currentPiece] = Color.BLACK;
						logic.updatePoints(colors);
						board.colors = colors;
						board.repaint();//Repaint the board
						if(logic.checkRow1()){//Check for a mill
							phase = 3;
							playState.setText("Game in Progress: Mill");
						}
						else if(playAI){
							phase = 2;
							AITurn();
						}
						else{//Go back to phase 2
							if(player==Color.BLUE){
								player=Color.RED;
								status.setForeground(Color.RED);
								status.setText("Current Player: RED");
							}
							else{
								player=Color.BLUE;
								status.setForeground(Color.BLUE);
								status.setText("Current Player: BLUE");
							}
							phase = 2;
							playState.setText("Game In Progress: Moving Pieces");
						}
					}
				}
			}
			else if((e.getX()>=490)&&(e.getX()<=510)&&(e.getY()>=90)&&(e.getY()<=110)){
				if(phase==1){//If the current phase is 1: Placing pieces
					if(colors[2]==Color.BLACK){//Can only place pieces on blank spaces
						colors[2] = player;//Update the color array
						board.colors = colors;
						board.repaint();//Repaint the board with the new colors
						playState.setText("Game In Progress: Placing pieces");
						//Switch to the next player and increment their respective Placed counters
						logic.addPiece(player);
						logic.updatePoints(colors);
						if(player == Color.BLUE){
							if(logic.checkRow1() || logic.checkCol4()){//If the player has formed a mill, move to the temporary 3rd phase: milling
								phase = 3;
								playState.setText("Game In Progress: Mill");
							}
							else{
								if(playAI==true){
									phase = logic.checkPhase();
									if(phase==2){
										playState.setText("Game In Progress: Moving Pieces");
									}
									AITurn();
								}
								else{
									status.setForeground(Color.RED);
									status.setText("Current player: RED");
									player = Color.RED;
									phase = logic.checkPhase();
									if(phase==2){
										playState.setText("Game In Progress: Moving Pieces");
									}
								}
							}
							
							}
						else{
							if(logic.checkRow1() || logic.checkCol4()){//If the player has formed a mill, move to the temporary 3rd phase: milling
								phase = 3;
								playState.setText("Game In Progress: Mill");
							}
							else{//If the player hasn't formed a mill, then go to the next player's turn
								status.setForeground(Color.BLUE);
								status.setText("Current Player: BLUE");
								player = Color.BLUE;
								phase = logic.checkPhase();
								if(phase==2){
									playState.setText("Game In Progress: Moving Pieces");
								}
							}	
						}
					}
				}
				else if(phase==0){//If the current phase is 0: Setting up a game in progress
					colors[2] = player;//Update the color array
					board.colors = colors;
					board.repaint();//Repaint the board with the new colors
					playState.setText("");
				}
				else if(phase==2){//If the current phase is 2: Choosing pieces to move
					if(player==Color.BLUE && colors[2]==Color.BLUE && logic.isMoveable(2)){//If the current player selects their own piece
						currentPiece = 2;//Update the current piece being moved
						phase = 4;//Move to the temporary 4th phase: moving the piece
						playState.setText("Game In Progress: Moving Piece 2");
					}
					else if(player==Color.RED && colors[2]==Color.RED && logic.isMoveable(2)){//If the current player selects their own piece
						currentPiece = 2;//Update the current piece being moved
						phase = 4;//Move to the temporary 4th phase: moving the piece
						playState.setText("Game In Progress: Moving Piece 2");
					}
				}
				else if(phase==3){//If the current phase is 3: milling
					if(player==Color.BLUE){
						if(colors[2]!=Color.BLACK && colors[2]!=Color.BLUE){//Check to see if the space isn't empty or if it isn't occupied by your own piece
							colors[2]=Color.BLACK;//Remove the piece and replace it with a blank piece
							board.colors = colors;
							board.repaint();//Repaint the board with the new colors
							logic.updatePoints(colors);
							logic.redPieces--;//Decrement the number of pieces red has remaining
							if(playAI==true){
								phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
								if(phase==1){playState.setText("Game In Progress: Placing pieces");}
								else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
								AITurn();
							}
							else{
								status.setForeground(Color.RED);//Switch to the next player
								status.setText("Current player: RED");
								player = Color.RED;
								phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
								if(phase==1){playState.setText("Game In Progress: Placing pieces");}
								else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
								}	
							}
					}
					else if(player==Color.RED){
						if(colors[2]!=Color.BLACK && colors[2]!=Color.RED){//Check to see if the space isn't empty or if it isn't occupied by your own piece
							colors[2]=Color.BLACK;//Remove the piece and replace it with a blank piece
							board.colors = colors;
							board.repaint();//Repaint the board with the new colors
							logic.updatePoints(colors);
							logic.bluePieces--;//Decrement the number of pieces blue has remaining
							status.setForeground(Color.BLUE);//Switch to the next player
							status.setText("Current Player: BLUE");
							player = Color.BLUE;
							phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
							if(phase==1){playState.setText("Game In Progress: Placing pieces");}
							else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
						}
					}
				}
				else if(phase==4){//If the current phase is 4: Moving a piece
					if(logic.validMove(currentPiece, 2)){
						colors[2] = player;//Update the color arrays
						colors[currentPiece] = Color.BLACK;
						logic.updatePoints(colors);
						board.colors = colors;
						board.repaint();//Repaint the board
						if(logic.checkRow1() || logic.checkCol4()){//Check for a mill
							phase = 3;
							playState.setText("Game in Progress: Mill");
						}
						else if(playAI){
							phase = 2;
							AITurn();
						}
						else{//Go back to phase 2
							if(player==Color.BLUE){
								player=Color.RED;
								status.setForeground(Color.RED);
								status.setText("Current Player: RED");
							}
							else{
								player=Color.BLUE;
								status.setForeground(Color.BLUE);
								status.setText("Current Player: BLUE");
							}
							phase = 2;
							playState.setText("Game In Progress: Moving Pieces");
						}
					}
				}
			}
			//Next row of spaces
			else if((e.getX()>=190)&&(e.getX()<=210)&&(e.getY()>=190)&&(e.getY()<=210)){
				if(phase==1){//If the current phase is 1: Placing pieces
					if(colors[3]==Color.BLACK){//Can only place pieces on blank spaces
						colors[3] = player;//Update the color array
						board.colors = colors;
						board.repaint();//Repaint the board with the new colors
						playState.setText("Game In Progress: Placing pieces");
						//Switch to the next player and increment their respective Placed counters
						logic.addPiece(player);
						logic.updatePoints(colors);
						if(player == Color.BLUE){
							if(logic.checkRow2() || logic.checkCol2()){//If the player has formed a mill, move to the temporary 3rd phase: milling
								phase = 3;
								playState.setText("Game In Progress: Mill");
							}
							else{
								if(playAI==true){
									phase = logic.checkPhase();
									if(phase==2){
										playState.setText("Game In Progress: Moving Pieces");
									}
									AITurn();
								}
								else{
									status.setForeground(Color.RED);
									status.setText("Current player: RED");
									player = Color.RED;
									phase = logic.checkPhase();
									if(phase==2){
										playState.setText("Game In Progress: Moving Pieces");
									}
								}
							}
							
							}
						else{
							if(logic.checkRow2() || logic.checkCol2()){//If the player has formed a mill, move to the temporary 3rd phase: milling
								phase = 3;
								playState.setText("Game In Progress: Mill");
							}
							else{//If the player hasn't formed a mill, then go to the next player's turn
								status.setForeground(Color.BLUE);
								status.setText("Current Player: BLUE");
								player = Color.BLUE;
								phase = logic.checkPhase();
								if(phase==2){
									playState.setText("Game In Progress: Moving Pieces");
								}
							}	
						}
					}
				}
				else if(phase==0){//If the current phase is 0: Setting up a game in progress
					colors[3] = player;//Update the color array
					board.colors = colors;
					board.repaint();//Repaint the board with the new colors
					playState.setText("");
				}
				else if(phase==2){//If the current phase is 2: Choosing pieces to move
					if(player==Color.BLUE && colors[3]==Color.BLUE && logic.isMoveable(3)){//If the current player selects their own piece
						currentPiece = 3;//Update the current piece being moved
						phase = 4;//Move to the temporary 4th phase: moving the piece
						playState.setText("Game In Progress: Moving Piece 3");
					}
					else if(player==Color.RED && colors[3]==Color.RED && logic.isMoveable(3)){//If the current player selects their own piece
						currentPiece = 3;//Update the current piece being moved
						phase = 4;//Move to the temporary 4th phase: moving the piece
						playState.setText("Game In Progress: Moving Piece 3");
					}
				}
				else if(phase==3){//If the current phase is 3: milling
					if(player==Color.BLUE){
						if(colors[3]!=Color.BLACK && colors[3]!=Color.BLUE){//Check to see if the space isn't empty or if it isn't occupied by your own piece
							colors[3]=Color.BLACK;//Remove the piece and replace it with a blank piece
							board.colors = colors;
							board.repaint();//Repaint the board with the new colors
							logic.updatePoints(colors);
							logic.redPieces--;//Decrement the number of pieces red has remaining
							if(playAI==true){
								phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
								if(phase==1){playState.setText("Game In Progress: Placing pieces");}
								else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
								AITurn();
							}
							else{
								status.setForeground(Color.RED);//Switch to the next player
								status.setText("Current player: RED");
								player = Color.RED;
								phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
								if(phase==1){playState.setText("Game In Progress: Placing pieces");}
								else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
								}	
							}
					}
					else if(player==Color.RED){
						if(colors[3]!=Color.BLACK && colors[3]!=Color.RED){//Check to see if the space isn't empty or if it isn't occupied by your own piece
							colors[3]=Color.BLACK;//Remove the piece and replace it with a blank piece
							board.colors = colors;
							board.repaint();//Repaint the board with the new colors
							logic.updatePoints(colors);
							logic.bluePieces--;//Decrement the number of pieces blue has remaining
							status.setForeground(Color.BLUE);//Switch to the next player
							status.setText("Current Player: BLUE");
							player = Color.BLUE;
							phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
							if(phase==1){playState.setText("Game In Progress: Placing pieces");}
							else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
						}
					}
				}
				else if(phase==4){//If the current phase is 4: Moving a piece
					if(logic.validMove(currentPiece, 3)){
						colors[3] = player;//Update the color arrays
						colors[currentPiece] = Color.BLACK;
						logic.updatePoints(colors);
						board.colors = colors;
						board.repaint();//Repaint the board
						if(logic.checkRow2() || logic.checkCol2()){//Check for a mill
							phase = 3;
							playState.setText("Game in Progress: Mill");
						}
						else if(playAI){
							phase = 2;
							AITurn();
						}
						else{//Switch to the next player and go back to phase 2
							if(player==Color.BLUE){
								player=Color.RED;
								status.setForeground(Color.RED);
								status.setText("Current Player: RED");
							}
							else{
								player=Color.BLUE;
								status.setForeground(Color.BLUE);
								status.setText("Current Player: BLUE");
							}
							phase = 2;
							playState.setText("Game In Progress: Moving Pieces");
						}
					}
				}
			}
			else if((e.getX()>=290)&&(e.getX()<=310)&&(e.getY()>=190)&&(e.getY()<=210)){
				if(phase==1){//If the current phase is 1: Placing pieces
					if(colors[4]==Color.BLACK){//Can only place pieces on blank spaces
						colors[4] = player;//Update the color array
						board.colors = colors;
						board.repaint();//Repaint the board with the new colors
						playState.setText("Game In Progress: Placing pieces");
						//Switch to the next player and increment their respective Placed counters
						logic.addPiece(player);
						logic.updatePoints(colors);
						if(player == Color.BLUE){
							if(logic.checkRow2()){//If the player has formed a mill, move to the temporary 3rd phase: milling
								phase = 3;
								playState.setText("Game In Progress: Mill");
							}
							else{
								if(playAI==true){
									phase = logic.checkPhase();
									if(phase==2){
										playState.setText("Game In Progress: Moving Pieces");
									}
									AITurn();
								}
								else{
									status.setForeground(Color.RED);
									status.setText("Current player: RED");
									player = Color.RED;
									phase = logic.checkPhase();
									if(phase==2){
										playState.setText("Game In Progress: Moving Pieces");
									}
								}
							}
							
							}
						else{
							if(logic.checkRow2()){//If the player has formed a mill, move to the temporary 3rd phase: milling
								phase = 3;
								playState.setText("Game In Progress: Mill");
							}
							else{//If the player hasn't formed a mill, then go to the next player's turn
								status.setForeground(Color.BLUE);
								status.setText("Current Player: BLUE");
								player = Color.BLUE;
								phase = logic.checkPhase();
								if(phase==2){
									playState.setText("Game In Progress: Moving Pieces");
								}
							}	
						}
					}
				}
				else if(phase==0){//If the current phase is 0: Setting up a game in progress
					colors[4] = player;//Update the color array
					board.colors = colors;
					board.repaint();//Repaint the board with the new colors
					playState.setText("");
				}
				else if(phase==2){//If the current phase is 2: Choosing pieces to move
					if(player==Color.BLUE && colors[4]==Color.BLUE && logic.isMoveable(4)){//If the current player selects their own piece
						currentPiece = 4;//Update the current piece being moved
						phase = 4;//Move to the temporary 4th phase: moving the piece
						playState.setText("Game In Progress: Moving Piece 4");
					}
					else if(player==Color.RED && colors[4]==Color.RED && logic.isMoveable(4)){//If the current player selects their own piece
						currentPiece = 4;//Update the current piece being moved
						phase = 4;//Move to the temporary 4th phase: moving the piece
						playState.setText("Game In Progress: Moving Piece 4");
					}
				}
				else if(phase==3){//If the current phase is 3: milling
					if(player==Color.BLUE){
						if(colors[4]!=Color.BLACK && colors[4]!=Color.BLUE){//Check to see if the space isn't empty or if it isn't occupied by your own piece
							colors[4]=Color.BLACK;//Remove the piece and replace it with a blank piece
							board.colors = colors;
							board.repaint();//Repaint the board with the new colors
							logic.updatePoints(colors);
							logic.redPieces--;//Decrement the number of pieces red has remaining
							if(playAI==true){
								phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
								if(phase==1){playState.setText("Game In Progress: Placing pieces");}
								else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
								AITurn();
							}
							else{
								status.setForeground(Color.RED);//Switch to the next player
								status.setText("Current player: RED");
								player = Color.RED;
								phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
								if(phase==1){playState.setText("Game In Progress: Placing pieces");}
								else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
								}	
							}
					}
					else if(player==Color.RED){
						if(colors[4]!=Color.BLACK && colors[4]!=Color.RED){//Check to see if the space isn't empty or if it isn't occupied by your own piece
							colors[4]=Color.BLACK;//Remove the piece and replace it with a blank piece
							board.colors = colors;
							board.repaint();//Repaint the board with the new colors
							logic.updatePoints(colors);
							logic.bluePieces--;//Decrement the number of pieces blue has remaining
							status.setForeground(Color.BLUE);//Switch to the next player
							status.setText("Current Player: BLUE");
							player = Color.BLUE;
							phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
							if(phase==1){playState.setText("Game In Progress: Placing pieces");}
							else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
						}
					}
				}
				else if(phase==4){//If the current phase is 4: Moving a piece
					if(logic.validMove(currentPiece, 4)){
						colors[4] = player;//Update the color arrays
						colors[currentPiece] = Color.BLACK;
						logic.updatePoints(colors);
						board.colors = colors;
						board.repaint();//Repaint the board
						if(logic.checkRow2()){//Check for a mill
							phase = 3;
							playState.setText("Game in Progress: Mill");
						}
						else if(playAI){
							phase = 2;
							AITurn();
						}
						else{//Switch to the next player and go back to phase 2
							if(player==Color.BLUE){
								player=Color.RED;
								status.setForeground(Color.RED);
								status.setText("Current Player: RED");
							}
							else{
								player=Color.BLUE;
								status.setForeground(Color.BLUE);
								status.setText("Current Player: BLUE");
							}
							phase = 2;
							playState.setText("Game In Progress: Moving Pieces");
						}
					}
				}
			}
			else if((e.getX()>=390)&&(e.getX()<=410)&&(e.getY()>=190)&&(e.getY()<=210)){
				if(phase==1){//If the current phase is 1: Placing pieces
					if(colors[5]==Color.BLACK){//Can only place pieces on blank spaces
						colors[5] = player;//Update the color array
						board.colors = colors;
						board.repaint();//Repaint the board with the new colors
						playState.setText("Game In Progress: Placing pieces");
						//Switch to the next player and increment their respective Placed counters
						logic.addPiece(player);
						logic.updatePoints(colors);
						if(player == Color.BLUE){
							if(logic.checkRow2() || logic.checkCol3()){//If the player has formed a mill, move to the temporary 3rd phase: milling
								phase = 3;
								playState.setText("Game In Progress: Mill");
							}
							else{
								if(playAI==true){
									phase = logic.checkPhase();
									if(phase==2){
										playState.setText("Game In Progress: Moving Pieces");
									}
									AITurn();
								}
								else{
									status.setForeground(Color.RED);
									status.setText("Current player: RED");
									player = Color.RED;
									phase = logic.checkPhase();
									if(phase==2){
										playState.setText("Game In Progress: Moving Pieces");
									}
								}
							}
						}
						else{
							if(logic.checkRow2() || logic.checkCol3()){//If the player has formed a mill, move to the temporary 3rd phase: milling
								phase = 3;
								playState.setText("Game In Progress: Mill");
							}
							else{//If the player hasn't formed a mill, then go to the next player's turn
								status.setForeground(Color.BLUE);
								status.setText("Current Player: BLUE");
								player = Color.BLUE;
								phase = logic.checkPhase();
								if(phase==2){
									playState.setText("Game In Progress: Moving Pieces");
								}
							}	
						}
					}
				}
				else if(phase==0){//If the current phase is 0: Setting up a game in progress
					colors[5] = player;//Update the color array
					board.colors = colors;
					board.repaint();//Repaint the board with the new colors
					playState.setText("");
				}
				else if(phase==2){//If the current phase is 2: Choosing pieces to move
					if(player==Color.BLUE && colors[5]==Color.BLUE && logic.isMoveable(5)){//If the current player selects their own piece
						currentPiece = 5;//Update the current piece being moved
						phase = 4;//Move to the temporary 4th phase: moving the piece
						playState.setText("Game In Progress: Moving Piece 5");
					}
					else if(player==Color.RED && colors[5]==Color.RED && logic.isMoveable(5)){//If the current player selects their own piece
						currentPiece = 5;//Update the current piece being moved
						phase = 4;//Move to the temporary 4th phase: moving the piece
						playState.setText("Game In Progress: Moving Piece 5");
					}
				}
				else if(phase==3){//If the current phase is 3: milling
					if(player==Color.BLUE){
						if(colors[5]!=Color.BLACK && colors[5]!=Color.BLUE){//Check to see if the space isn't empty or if it isn't occupied by your own piece
							colors[5]=Color.BLACK;//Remove the piece and replace it with a blank piece
							board.colors = colors;
							board.repaint();//Repaint the board with the new colors
							logic.updatePoints(colors);
							logic.redPieces--;//Decrement the number of pieces red has remaining
							if(playAI==true){
								phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
								if(phase==1){playState.setText("Game In Progress: Placing pieces");}
								else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
								AITurn();
							}
							else{
								status.setForeground(Color.RED);//Switch to the next player
								status.setText("Current player: RED");
								player = Color.RED;
								phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
								if(phase==1){playState.setText("Game In Progress: Placing pieces");}
								else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
								}	
							}
					}
					else if(player==Color.RED){
						if(colors[5]!=Color.BLACK && colors[5]!=Color.RED){//Check to see if the space isn't empty or if it isn't occupied by your own piece
							colors[5]=Color.BLACK;//Remove the piece and replace it with a blank piece
							board.colors = colors;
							board.repaint();//Repaint the board with the new colors
							logic.updatePoints(colors);
							logic.bluePieces--;//Decrement the number of pieces blue has remaining
							status.setForeground(Color.BLUE);//Switch to the next player
							status.setText("Current Player: BLUE");
							player = Color.BLUE;
							phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
							if(phase==1){playState.setText("Game In Progress: Placing pieces");}
							else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
						}
					}
				}
				else if(phase==4){//If the current phase is 4: Moving a piece
					if(logic.validMove(currentPiece, 5)){
						colors[5] = player;//Update the color arrays
						colors[currentPiece] = Color.BLACK;
						logic.updatePoints(colors);
						board.colors = colors;
						board.repaint();//Repaint the board
						if(logic.checkRow2() || logic.checkCol3()){//Check for a mill
							phase = 3;
							playState.setText("Game in Progress: Mill");
						}
						else if(playAI){
							phase = 2;
							AITurn();
						}
						else{//Switch to the next player and go back to phase 2
							if(player==Color.BLUE){
								player=Color.RED;
								status.setForeground(Color.RED);
								status.setText("Current Player: RED");
							}
							else{
								player=Color.BLUE;
								status.setForeground(Color.BLUE);
								status.setText("Current Player: BLUE");
							}
							phase = 2;
							playState.setText("Game In Progress: Moving Pieces");
						}
					}
				}
			}
			//Next row of spaces
			else if((e.getX()>=90)&&(e.getX()<=110)&&(e.getY()>=290)&&(e.getY()<=310)){
				if(phase==1){//If the current phase is 1: Placing pieces
					if(colors[6]==Color.BLACK){//Can only place pieces on blank spaces
						colors[6] = player;//Update the color array
						board.colors = colors;
						board.repaint();//Repaint the board with the new colors
						playState.setText("Game In Progress: Placing pieces");
						//Switch to the next player and increment their respective Placed counters
						logic.addPiece(player);
						logic.updatePoints(colors);
						if(player == Color.BLUE){
							if(logic.checkCol1()){//If the player has formed a mill, move to the temporary 3rd phase: milling
								phase = 3;
								playState.setText("Game In Progress: Mill");
							}
							else{
								if(playAI==true){
									phase = logic.checkPhase();
									if(phase==2){
										playState.setText("Game In Progress: Moving Pieces");
									}
									AITurn();
								}
								else{
									status.setForeground(Color.RED);
									status.setText("Current player: RED");
									player = Color.RED;
									phase = logic.checkPhase();
									if(phase==2){
										playState.setText("Game In Progress: Moving Pieces");
									}
								}
							}
						}
						else{
							if(logic.checkCol1()){//If the player has formed a mill, move to the temporary 3rd phase: milling
								phase = 3;
								playState.setText("Game In Progress: Mill");
							}
							else{//If the player hasn't formed a mill, then go to the next player's turn
								status.setForeground(Color.BLUE);
								status.setText("Current Player: BLUE");
								player = Color.BLUE;
								phase = logic.checkPhase();
								if(phase==2){
									playState.setText("Game In Progress: Moving Pieces");
								}
							}	
						}
					}
				}
				else if(phase==0){//If the current phase is 0: Setting up a game in progress
					colors[6] = player;//Update the color array
					board.colors = colors;
					board.repaint();//Repaint the board with the new colors
					playState.setText("");
				}
				else if(phase==2){//If the current phase is 2: Choosing pieces to move
					if(player==Color.BLUE && colors[6]==Color.BLUE && logic.isMoveable(6)){//If the current player selects their own piece
						currentPiece = 6;//Update the current piece being moved
						phase = 4;//Move to the temporary 4th phase: moving the piece
						playState.setText("Game In Progress: Moving Piece 6");
					}
					else if(player==Color.RED && colors[6]==Color.RED && logic.isMoveable(6)){//If the current player selects their own piece
						currentPiece = 6;//Update the current piece being moved
						phase = 4;//Move to the temporary 4th phase: moving the piece
						playState.setText("Game In Progress: Moving Piece 6");
					}
				}
				else if(phase==3){//If the current phase is 3: milling
					if(player==Color.BLUE){
						if(colors[6]!=Color.BLACK && colors[6]!=Color.BLUE){//Check to see if the space isn't empty or if it isn't occupied by your own piece
							colors[6]=Color.BLACK;//Remove the piece and replace it with a blank piece
							board.colors = colors;
							board.repaint();//Repaint the board with the new colors
							logic.updatePoints(colors);
							logic.redPieces--;//Decrement the number of pieces red has remaining
							if(playAI==true){
								phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
								if(phase==1){playState.setText("Game In Progress: Placing pieces");}
								else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
								AITurn();
							}
							else{
								status.setForeground(Color.RED);//Switch to the next player
								status.setText("Current player: RED");
								player = Color.RED;
								phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
								if(phase==1){playState.setText("Game In Progress: Placing pieces");}
								else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
								}	
							}
					}
					else if(player==Color.RED){
						if(colors[6]!=Color.BLACK && colors[6]!=Color.RED){//Check to see if the space isn't empty or if it isn't occupied by your own piece
							colors[6]=Color.BLACK;//Remove the piece and replace it with a blank piece
							board.colors = colors;
							board.repaint();//Repaint the board with the new colors
							logic.updatePoints(colors);
							logic.bluePieces--;//Decrement the number of pieces blue has remaining
							status.setForeground(Color.BLUE);//Switch to the next player
							status.setText("Current Player: BLUE");
							player = Color.BLUE;
							phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
							if(phase==1){playState.setText("Game In Progress: Placing pieces");}
							else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
						}
					}
				}
				else if(phase==4){//If the current phase is 4: Moving a piece
					if(logic.validMove(currentPiece, 6)){
						colors[6] = player;//Update the color arrays
						colors[currentPiece] = Color.BLACK;
						logic.updatePoints(colors);
						board.colors = colors;
						board.repaint();//Repaint the board
						if(logic.checkCol1()){//Check for a mill
							phase = 3;
							playState.setText("Game in Progress: Mill");
						}
						else if(playAI){
							phase = 2;
							AITurn();
						}
						else{//Switch to the next player and go back to phase 2
							if(player==Color.BLUE){
								player=Color.RED;
								status.setForeground(Color.RED);
								status.setText("Current Player: RED");
							}
							else{
								player=Color.BLUE;
								status.setForeground(Color.BLUE);
								status.setText("Current Player: BLUE");
							}
							phase = 2;
							playState.setText("Game In Progress: Moving Pieces");
						}
					}
				}
			}
			else if((e.getX()>=190)&&(e.getX()<=210)&&(e.getY()>=290)&&(e.getY()<=310)){
				if(phase==1){//If the current phase is 1: Placing pieces
					if(colors[7]==Color.BLACK){//Can only place pieces on blank spaces
						colors[7] = player;//Update the color array
						board.colors = colors;
						board.repaint();//Repaint the board with the new colors
						playState.setText("Game In Progress: Placing pieces");
						//Switch to the next player and increment their respective Placed counters
						logic.addPiece(player);
						logic.updatePoints(colors);
						if(player == Color.BLUE){
							if(logic.checkCol2()){//If the player has formed a mill, move to the temporary 3rd phase: milling
								phase = 3;
								playState.setText("Game In Progress: Mill");
							}
							else{
								if(playAI==true){
									phase = logic.checkPhase();
									if(phase==2){
										playState.setText("Game In Progress: Moving Pieces");
									}
									AITurn();
								}
								else{
									status.setForeground(Color.RED);
									status.setText("Current player: RED");
									player = Color.RED;
									phase = logic.checkPhase();
									if(phase==2){
										playState.setText("Game In Progress: Moving Pieces");
									}
								}
							}
						}
						else{
							if(logic.checkCol2()){//If the player has formed a mill, move to the temporary 3rd phase: milling
								phase = 3;
								playState.setText("Game In Progress: Mill");
							}
							else{//If the player hasn't formed a mill, then go to the next player's turn
								status.setForeground(Color.BLUE);
								status.setText("Current Player: BLUE");
								player = Color.BLUE;
								phase = logic.checkPhase();
								if(phase==2){
									playState.setText("Game In Progress: Moving Pieces");
								}
							}	
						}
					}
				}
				else if(phase==0){//If the current phase is 0: Setting up a game in progress
					colors[7] = player;//Update the color array
					board.colors = colors;
					board.repaint();//Repaint the board with the new colors
					playState.setText("");
				}
				else if(phase==2){//If the current phase is 2: Choosing pieces to move
					if(player==Color.BLUE && colors[7]==Color.BLUE && logic.isMoveable(7)){//If the current player selects their own piece
						currentPiece = 7;//Update the current piece being moved
						phase = 4;//Move to the temporary 4th phase: moving the piece
						playState.setText("Game In Progress: Moving Piece 7");
					}
					else if(player==Color.RED && colors[7]==Color.RED && logic.isMoveable(7)){//If the current player selects their own piece
						currentPiece = 7;//Update the current piece being moved
						phase = 4;//Move to the temporary 4th phase: moving the piece
						playState.setText("Game In Progress: Moving Piece 7");
					}
				}
				else if(phase==3){//If the current phase is 3: milling
					if(player==Color.BLUE){
						if(colors[7]!=Color.BLACK && colors[7]!=Color.BLUE){//Check to see if the space isn't empty or if it isn't occupied by your own piece
							colors[7]=Color.BLACK;//Remove the piece and replace it with a blank piece
							board.colors = colors;
							board.repaint();//Repaint the board with the new colors
							logic.updatePoints(colors);
							logic.redPieces--;//Decrement the number of pieces red has remaining
							if(playAI==true){
								phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
								if(phase==1){playState.setText("Game In Progress: Placing pieces");}
								else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
								AITurn();
							}
							else{
								status.setForeground(Color.RED);//Switch to the next player
								status.setText("Current player: RED");
								player = Color.RED;
								phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
								if(phase==1){playState.setText("Game In Progress: Placing pieces");}
								else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
								}	
							}
					}
					else if(player==Color.RED){
						if(colors[7]!=Color.BLACK && colors[7]!=Color.RED){//Check to see if the space isn't empty or if it isn't occupied by your own piece
							colors[7]=Color.BLACK;//Remove the piece and replace it with a blank piece
							board.colors = colors;
							board.repaint();//Repaint the board with the new colors
							logic.updatePoints(colors);
							logic.bluePieces--;//Decrement the number of pieces blue has remaining
							status.setForeground(Color.BLUE);//Switch to the next player
							status.setText("Current Player: BLUE");
							player = Color.BLUE;
							phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
							if(phase==1){playState.setText("Game In Progress: Placing pieces");}
							else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
						}
					}
				}
				else if(phase==4){//If the current phase is 4: Moving a piece
					if(logic.validMove(currentPiece, 7)){
						colors[7] = player;//Update the color arrays
						colors[currentPiece] = Color.BLACK;
						logic.updatePoints(colors);
						board.colors = colors;
						board.repaint();//Repaint the board
						if(logic.checkCol2()){//Check for a mill
							phase = 3;
							playState.setText("Game in Progress: Mill");
						}
						else if(playAI){
							phase = 2;
							AITurn();
						}
						else{//Switch to the next player and go back to phase 2
							if(player==Color.BLUE){
								player=Color.RED;
								status.setForeground(Color.RED);
								status.setText("Current Player: RED");
							}
							else{
								player=Color.BLUE;
								status.setForeground(Color.BLUE);
								status.setText("Current Player: BLUE");
							}
							phase = 2;
							playState.setText("Game In Progress: Moving Pieces");
						}
					}
				}
			}
			else if((e.getX()>=390)&&(e.getX()<=410)&&(e.getY()>=290)&&(e.getY()<=310)){
				if(phase==1){//If the current phase is 1: Placing pieces
					if(colors[8]==Color.BLACK){//Can only place pieces on blank spaces
						colors[8] = player;//Update the color array
						board.colors = colors;
						board.repaint();//Repaint the board with the new colors
						playState.setText("Game In Progress: Placing pieces");
						//Switch to the next player and increment their respective Placed counters
						logic.addPiece(player);
						logic.updatePoints(colors);
						if(player == Color.BLUE){
							if(logic.checkCol3()){//If the player has formed a mill, move to the temporary 3rd phase: milling
								phase = 3;
								playState.setText("Game In Progress: Mill");
							}
							else{
								if(playAI==true){
									phase = logic.checkPhase();
									if(phase==2){
										playState.setText("Game In Progress: Moving Pieces");
									}
									AITurn();
								}
								else{
									status.setForeground(Color.RED);
									status.setText("Current player: RED");
									player = Color.RED;
									phase = logic.checkPhase();
									if(phase==2){
										playState.setText("Game In Progress: Moving Pieces");
									}
								}
							}
						}
						else{
							if(logic.checkCol3()){//If the player has formed a mill, move to the temporary 3rd phase: milling
								phase = 3;
								playState.setText("Game In Progress: Mill");
							}
							else{//If the player hasn't formed a mill, then go to the next player's turn
								status.setForeground(Color.BLUE);
								status.setText("Current Player: BLUE");
								player = Color.BLUE;
								phase = logic.checkPhase();
								if(phase==2){
									playState.setText("Game In Progress: Moving Pieces");
								}
							}	
						}
					}
				}
				else if(phase==0){//If the current phase is 0: Setting up a game in progress
					colors[8] = player;//Update the color array
					board.colors = colors;
					board.repaint();//Repaint the board with the new colors
					playState.setText("");
				}
				else if(phase==2){//If the current phase is 2: Choosing pieces to move
					if(player==Color.BLUE && colors[8]==Color.BLUE && logic.isMoveable(8)){//If the current player selects their own piece
						currentPiece = 8;//Update the current piece being moved
						phase = 4;//Move to the temporary 4th phase: moving the piece
						playState.setText("Game In Progress: Moving Piece 8");
					}
					else if(player==Color.RED && colors[8]==Color.RED && logic.isMoveable(8)){//If the current player selects their own piece
						currentPiece = 8;//Update the current piece being moved
						phase = 4;//Move to the temporary 4th phase: moving the piece
						playState.setText("Game In Progress: Moving Piece 8");
					}
				}
				else if(phase==3){//If the current phase is 3: milling
					if(player==Color.BLUE){
						if(colors[8]!=Color.BLACK && colors[8]!=Color.BLUE){//Check to see if the space isn't empty or if it isn't occupied by your own piece
							colors[8]=Color.BLACK;//Remove the piece and replace it with a blank piece
							board.colors = colors;
							board.repaint();//Repaint the board with the new colors
							logic.updatePoints(colors);
							logic.redPieces--;//Decrement the number of pieces red has remaining
							if(playAI==true){
								phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
								if(phase==1){playState.setText("Game In Progress: Placing pieces");}
								else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
								AITurn();
							}
							else{
								status.setForeground(Color.RED);//Switch to the next player
								status.setText("Current player: RED");
								player = Color.RED;
								phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
								if(phase==1){playState.setText("Game In Progress: Placing pieces");}
								else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
								}	
							}
					}
					else if(player==Color.RED){
						if(colors[8]!=Color.BLACK && colors[8]!=Color.RED){//Check to see if the space isn't empty or if it isn't occupied by your own piece
							colors[8]=Color.BLACK;//Remove the piece and replace it with a blank piece
							board.colors = colors;
							board.repaint();//Repaint the board with the new colors
							logic.updatePoints(colors);
							logic.bluePieces--;//Decrement the number of pieces blue has remaining
							status.setForeground(Color.BLUE);//Switch to the next player
							status.setText("Current Player: BLUE");
							player = Color.BLUE;
							phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
							if(phase==1){playState.setText("Game In Progress: Placing pieces");}
							else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
						}
					}
				}
				else if(phase==4){//If the current phase is 4: Moving a piece
					if(logic.validMove(currentPiece, 8)){
						colors[8] = player;//Update the color arrays
						colors[currentPiece] = Color.BLACK;
						logic.updatePoints(colors);
						board.colors = colors;
						board.repaint();//Repaint the board
						if(logic.checkCol3()){//Check for a mill
							phase = 3;
							playState.setText("Game in Progress: Mill");
						}
						else if(playAI){
							phase = 2;
							AITurn();
						}
						else{//Switch to the next player and go back to phase 2
							if(player==Color.BLUE){
								player=Color.RED;
								status.setForeground(Color.RED);
								status.setText("Current Player: RED");
							}
							else{
								player=Color.BLUE;
								status.setForeground(Color.BLUE);
								status.setText("Current Player: BLUE");
							}
							phase = 2;
							playState.setText("Game In Progress: Moving Pieces");
						}
					}
				}
			}
			else if((e.getX()>=490)&&(e.getX()<=510)&&(e.getY()>=290)&&(e.getY()<=310)){
				if(phase==1){//If the current phase is 1: Placing pieces
					if(colors[9]==Color.BLACK){//Can only place pieces on blank spaces
						colors[9] = player;//Update the color array
						board.colors = colors;
						board.repaint();//Repaint the board with the new colors
						playState.setText("Game In Progress: Placing pieces");
						//Switch to the next player and increment their respective Placed counters
						logic.addPiece(player);
						logic.updatePoints(colors);
						if(player == Color.BLUE){
							if(logic.checkCol4()){//If the player has formed a mill, move to the temporary 3rd phase: milling
								phase = 3;
								playState.setText("Game In Progress: Mill");
							}
							else{
								if(playAI==true){
									phase = logic.checkPhase();
									if(phase==2){
										playState.setText("Game In Progress: Moving Pieces");
									}
									AITurn();
								}
								else{
									status.setForeground(Color.RED);
									status.setText("Current player: RED");
									player = Color.RED;
									phase = logic.checkPhase();
									if(phase==2){
										playState.setText("Game In Progress: Moving Pieces");
									}
								}
							}
						}
						else{
							if(logic.checkCol4()){//If the player has formed a mill, move to the temporary 3rd phase: milling
								phase = 3;
								playState.setText("Game In Progress: Mill");
							}
							else{//If the player hasn't formed a mill, then go to the next player's turn
								status.setForeground(Color.BLUE);
								status.setText("Current Player: BLUE");
								player = Color.BLUE;
								phase = logic.checkPhase();
								if(phase==2){
									playState.setText("Game In Progress: Moving Pieces");
								}
							}	
						}
					}
				}
				else if(phase==0){//If the current phase is 0: Setting up a game in progress
					colors[9] = player;//Update the color array
					board.colors = colors;
					board.repaint();//Repaint the board with the new colors
					playState.setText("");
				}
				else if(phase==2){//If the current phase is 2: Choosing pieces to move
					if(player==Color.BLUE && colors[9]==Color.BLUE && logic.isMoveable(9)){//If the current player selects their own piece
						currentPiece = 9;//Update the current piece being moved
						phase = 4;//Move to the temporary 4th phase: moving the piece
						playState.setText("Game In Progress: Moving Piece 9");
					}
					else if(player==Color.RED && colors[9]==Color.RED && logic.isMoveable(9)){//If the current player selects their own piece
						currentPiece = 9;//Update the current piece being moved
						phase = 4;//Move to the temporary 4th phase: moving the piece
						playState.setText("Game In Progress: Moving Piece 9");
					}
				}
				else if(phase==3){//If the current phase is 3: milling
					if(player==Color.BLUE){
						if(colors[9]!=Color.BLACK && colors[9]!=Color.BLUE){//Check to see if the space isn't empty or if it isn't occupied by your own piece
							colors[9]=Color.BLACK;//Remove the piece and replace it with a blank piece
							board.colors = colors;
							board.repaint();//Repaint the board with the new colors
							logic.updatePoints(colors);
							logic.redPieces--;//Decrement the number of pieces red has remaining
							if(playAI==true){
								phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
								if(phase==1){playState.setText("Game In Progress: Placing pieces");}
								else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
								AITurn();
							}
							else{
								status.setForeground(Color.RED);//Switch to the next player
								status.setText("Current player: RED");
								player = Color.RED;
								phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
								if(phase==1){playState.setText("Game In Progress: Placing pieces");}
								else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
								}	
							}
					}
					else if(player==Color.RED){
						if(colors[9]!=Color.BLACK && colors[9]!=Color.RED){//Check to see if the space isn't empty or if it isn't occupied by your own piece
							colors[9]=Color.BLACK;//Remove the piece and replace it with a blank piece
							board.colors = colors;
							board.repaint();//Repaint the board with the new colors
							logic.updatePoints(colors);
							logic.bluePieces--;//Decrement the number of pieces blue has remaining
							status.setForeground(Color.BLUE);//Switch to the next player
							status.setText("Current Player: BLUE");
							player = Color.BLUE;
							phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
							if(phase==1){playState.setText("Game In Progress: Placing pieces");}
							else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
						}
					}
				}
				else if(phase==4){//If the current phase is 4: Moving a piece
					if(logic.validMove(currentPiece, 9)){
						colors[9] = player;//Update the color arrays
						colors[currentPiece] = Color.BLACK;
						logic.updatePoints(colors);
						board.colors = colors;
						board.repaint();//Repaint the board
						if(logic.checkCol4()){//Check for a mill
							phase = 3;
							playState.setText("Game in Progress: Mill");
						}
						else if(playAI){
							phase = 2;
							AITurn();
						}
						else{//Switch to the next player and go back to phase 2
							if(player==Color.BLUE){
								player=Color.RED;
								status.setForeground(Color.RED);
								status.setText("Current Player: RED");
							}
							else{
								player=Color.BLUE;
								status.setForeground(Color.BLUE);
								status.setText("Current Player: BLUE");
							}
							phase = 2;
							playState.setText("Game In Progress: Moving Pieces");
						}
					}
				}
			}
			//Next row of spaces
			else if((e.getX()>=190)&&(e.getX()<=210)&&(e.getY()>=390)&&(e.getY()<=410)){
				if(phase==1){//If the current phase is 1: Placing pieces
					if(colors[10]==Color.BLACK){//Can only place pieces on blank spaces
						colors[10] = player;//Update the color array
						board.colors = colors;
						board.repaint();//Repaint the board with the new colors
						playState.setText("Game In Progress: Placing pieces");
						//Switch to the next player and increment their respective Placed counters
						logic.addPiece(player);
						logic.updatePoints(colors);
						if(player == Color.BLUE){
							if(logic.checkRow3() || logic.checkCol2()){//If the player has formed a mill, move to the temporary 3rd phase: milling
								phase = 3;
								playState.setText("Game In Progress: Mill");
							}
							else{
								if(playAI==true){
									phase = logic.checkPhase();
									if(phase==2){
										playState.setText("Game In Progress: Moving Pieces");
									}
									AITurn();
								}
								else{
									status.setForeground(Color.RED);
									status.setText("Current player: RED");
									player = Color.RED;
									phase = logic.checkPhase();
									if(phase==2){
										playState.setText("Game In Progress: Moving Pieces");
									}
								}
							}
						}
						else{
							if(logic.checkRow3() || logic.checkCol2()){//If the player has formed a mill, move to the temporary 3rd phase: milling
								phase = 3;
								playState.setText("Game In Progress: Mill");
							}
							else{//If the player hasn't formed a mill, then go to the next player's turn
								status.setForeground(Color.BLUE);
								status.setText("Current Player: BLUE");
								player = Color.BLUE;
								phase = logic.checkPhase();
								if(phase==2){
									playState.setText("Game In Progress: Moving Pieces");
								}
							}	
						}
					}
				}
				else if(phase==0){//If the current phase is 0: Setting up a game in progress
					colors[10] = player;//Update the color array
					board.colors = colors;
					board.repaint();//Repaint the board with the new colors
					playState.setText("");
				}
				else if(phase==2){//If the current phase is 2: Choosing pieces to move
					if(player==Color.BLUE && colors[10]==Color.BLUE && logic.isMoveable(10)){//If the current player selects their own piece
						currentPiece = 10;//Update the current piece being moved
						phase = 4;//Move to the temporary 4th phase: moving the piece
						playState.setText("Game In Progress: Moving Piece 10");
					}
					else if(player==Color.RED && colors[10]==Color.RED && logic.isMoveable(10)){//If the current player selects their own piece
						currentPiece = 10;//Update the current piece being moved
						phase = 4;//Move to the temporary 4th phase: moving the piece
						playState.setText("Game In Progress: Moving Piece 10");
					}
				}
				else if(phase==3){//If the current phase is 3: milling
					if(player==Color.BLUE){
						if(colors[10]!=Color.BLACK && colors[10]!=Color.BLUE){//Check to see if the space isn't empty or if it isn't occupied by your own piece
							colors[10]=Color.BLACK;//Remove the piece and replace it with a blank piece
							board.colors = colors;
							board.repaint();//Repaint the board with the new colors
							logic.updatePoints(colors);
							logic.redPieces--;//Decrement the number of pieces red has remaining
							if(playAI==true){
								phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
								if(phase==1){playState.setText("Game In Progress: Placing pieces");}
								else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
								AITurn();
							}
							else{
								status.setForeground(Color.RED);//Switch to the next player
								status.setText("Current player: RED");
								player = Color.RED;
								phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
								if(phase==1){playState.setText("Game In Progress: Placing pieces");}
								else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
								}	
							}
					}
					else if(player==Color.RED){
						if(colors[10]!=Color.BLACK && colors[10]!=Color.RED){//Check to see if the space isn't empty or if it isn't occupied by your own piece
							colors[10]=Color.BLACK;//Remove the piece and replace it with a blank piece
							board.colors = colors;
							board.repaint();//Repaint the board with the new colors
							logic.updatePoints(colors);
							logic.bluePieces--;//Decrement the number of pieces blue has remaining
							status.setForeground(Color.BLUE);//Switch to the next player
							status.setText("Current Player: BLUE");
							player = Color.BLUE;
							phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
							if(phase==1){playState.setText("Game In Progress: Placing pieces");}
							else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
						}
					}
				}
				else if(phase==4){//If the current phase is 4: Moving a piece
					if(logic.validMove(currentPiece, 10)){
						colors[10] = player;//Update the color arrays
						colors[currentPiece] = Color.BLACK;
						logic.updatePoints(colors);
						board.colors = colors;
						board.repaint();//Repaint the board
						if(logic.checkRow3() || logic.checkCol2()){//Check for a mill
							phase = 3;
							playState.setText("Game in Progress: Mill");
						}
						else if(playAI){
							phase = 2;
							AITurn();
						}
						else{//Switch to the next player and go back to phase 2
							if(player==Color.BLUE){
								player=Color.RED;
								status.setForeground(Color.RED);
								status.setText("Current Player: RED");
							}
							else{
								player=Color.BLUE;
								status.setForeground(Color.BLUE);
								status.setText("Current Player: BLUE");
							}
							phase = 2;
							playState.setText("Game In Progress: Moving Pieces");
						}
					}
				}
			}
			else if((e.getX()>=290)&&(e.getX()<=310)&&(e.getY()>=390)&&(e.getY()<=410)){
				if(phase==1){//If the current phase is 1: Placing pieces
					if(colors[11]==Color.BLACK){//Can only place pieces on blank spaces
						colors[11] = player;//Update the color array
						board.colors = colors;
						board.repaint();//Repaint the board with the new colors
						playState.setText("Game In Progress: Placing pieces");
						//Switch to the next player and increment their respective Placed counters
						logic.addPiece(player);
						logic.updatePoints(colors);
						if(player == Color.BLUE){
							if(logic.checkRow3()){//If the player has formed a mill, move to the temporary 3rd phase: milling
								phase = 3;
								playState.setText("Game In Progress: Mill");
							}
							else{
								if(playAI==true){
									phase = logic.checkPhase();
									if(phase==2){
										playState.setText("Game In Progress: Moving Pieces");
									}
									AITurn();
								}
								else{
									status.setForeground(Color.RED);
									status.setText("Current player: RED");
									player = Color.RED;
									phase = logic.checkPhase();
									if(phase==2){
										playState.setText("Game In Progress: Moving Pieces");
									}
								}
							}
						}
						else{
							if(logic.checkRow3()){//If the player has formed a mill, move to the temporary 3rd phase: milling
								phase = 3;
								playState.setText("Game In Progress: Mill");
							}
							else{//If the player hasn't formed a mill, then go to the next player's turn
								status.setForeground(Color.BLUE);
								status.setText("Current Player: BLUE");
								player = Color.BLUE;
								phase = logic.checkPhase();
								if(phase==2){
									playState.setText("Game In Progress: Moving Pieces");
								}
							}	
						}
					}
				}
				else if(phase==0){//If the current phase is 0: Setting up a game in progress
					colors[11] = player;//Update the color array
					board.colors = colors;
					board.repaint();//Repaint the board with the new colors
					playState.setText("");
				}
				else if(phase==2){//If the current phase is 2: Choosing pieces to move
					if(player==Color.BLUE && colors[11]==Color.BLUE && logic.isMoveable(11)){//If the current player selects their own piece
						currentPiece = 11;//Update the current piece being moved
						phase = 4;//Move to the temporary 4th phase: moving the piece
						playState.setText("Game In Progress: Moving Piece 11");
					}
					else if(player==Color.RED && colors[11]==Color.RED && logic.isMoveable(11)){//If the current player selects their own piece
						currentPiece = 11;//Update the current piece being moved
						phase = 4;//Move to the temporary 4th phase: moving the piece
						playState.setText("Game In Progress: Moving Piece 11");
					}
				}
				else if(phase==3){//If the current phase is 3: milling
					if(player==Color.BLUE){
						if(colors[11]!=Color.BLACK && colors[11]!=Color.BLUE){//Check to see if the space isn't empty or if it isn't occupied by your own piece
							colors[11]=Color.BLACK;//Remove the piece and replace it with a blank piece
							board.colors = colors;
							board.repaint();//Repaint the board with the new colors
							logic.updatePoints(colors);
							logic.redPieces--;//Decrement the number of pieces red has remaining
							if(playAI==true){
								phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
								if(phase==1){playState.setText("Game In Progress: Placing pieces");}
								else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
								AITurn();
							}
							else{
								status.setForeground(Color.RED);//Switch to the next player
								status.setText("Current player: RED");
								player = Color.RED;
								phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
								if(phase==1){playState.setText("Game In Progress: Placing pieces");}
								else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
								}	
							}
					}
					else if(player==Color.RED){
						if(colors[11]!=Color.BLACK && colors[11]!=Color.RED){//Check to see if the space isn't empty or if it isn't occupied by your own piece
							colors[11]=Color.BLACK;//Remove the piece and replace it with a blank piece
							board.colors = colors;
							board.repaint();//Repaint the board with the new colors
							logic.updatePoints(colors);
							logic.bluePieces--;//Decrement the number of pieces blue has remaining
							status.setForeground(Color.BLUE);//Switch to the next player
							status.setText("Current Player: BLUE");
							player = Color.BLUE;
							phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
							if(phase==1){playState.setText("Game In Progress: Placing pieces");}
							else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
						}
					}
				}
				else if(phase==4){//If the current phase is 4: Moving a piece
					if(logic.validMove(currentPiece, 11)){
						colors[11] = player;//Update the color arrays
						colors[currentPiece] = Color.BLACK;
						logic.updatePoints(colors);
						board.colors = colors;
						board.repaint();//Repaint the board
						if(logic.checkRow3()){//Check for a mill
							phase = 3;
							playState.setText("Game in Progress: Mill");
						}
						else if(playAI){
							phase = 2;
							AITurn();
						}
						else{//Switch to the next player and go back to phase 2
							if(player==Color.BLUE){
								player=Color.RED;
								status.setForeground(Color.RED);
								status.setText("Current Player: RED");
							}
							else{
								player=Color.BLUE;
								status.setForeground(Color.BLUE);
								status.setText("Current Player: BLUE");
							}
							phase = 2;
							playState.setText("Game In Progress: Moving Pieces");
						}
					}
				}
			}
			else if((e.getX()>=390)&&(e.getX()<=410)&&(e.getY()>=390)&&(e.getY()<=410)){
				if(phase==1){//If the current phase is 1: Placing pieces
					if(colors[12]==Color.BLACK){//Can only place pieces on blank spaces
						colors[12] = player;//Update the color array
						board.colors = colors;
						board.repaint();//Repaint the board with the new colors
						playState.setText("Game In Progress: Placing pieces");
						//Switch to the next player and increment their respective Placed counters
						logic.addPiece(player);
						logic.updatePoints(colors);
						if(player == Color.BLUE){
							if(logic.checkRow3() || logic.checkCol3()){//If the player has formed a mill, move to the temporary 3rd phase: milling
								phase = 3;
								playState.setText("Game In Progress: Mill");
							}
							else{
								if(playAI==true){
									phase = logic.checkPhase();
									if(phase==2){
										playState.setText("Game In Progress: Moving Pieces");
									}
									AITurn();
								}
								else{
									status.setForeground(Color.RED);
									status.setText("Current player: RED");
									player = Color.RED;
									phase = logic.checkPhase();
									if(phase==2){
										playState.setText("Game In Progress: Moving Pieces");
									}
								}
							}
						}
						else{
							if(logic.checkRow3() || logic.checkCol3()){//If the player has formed a mill, move to the temporary 3rd phase: milling
								phase = 3;
								playState.setText("Game In Progress: Mill");
							}
							else{//If the player hasn't formed a mill, then go to the next player's turn
								status.setForeground(Color.BLUE);
								status.setText("Current Player: BLUE");
								player = Color.BLUE;
								phase = logic.checkPhase();
								if(phase==2){
									playState.setText("Game In Progress: Moving Pieces");
								}
							}	
						}
					}
				}
				else if(phase==0){//If the current phase is 0: Setting up a game in progress
					colors[12] = player;//Update the color array
					board.colors = colors;
					board.repaint();//Repaint the board with the new colors
					playState.setText("");
				}
				else if(phase==2){//If the current phase is 2: Choosing pieces to move
					if(player==Color.BLUE && colors[12]==Color.BLUE && logic.isMoveable(12)){//If the current player selects their own piece
						currentPiece = 12;//Update the current piece being moved
						phase = 4;//Move to the temporary 4th phase: moving the piece
						playState.setText("Game In Progress: Moving Piece 12");
					}
					else if(player==Color.RED && colors[12]==Color.RED && logic.isMoveable(12)){//If the current player selects their own piece
						currentPiece = 12;//Update the current piece being moved
						phase = 4;//Move to the temporary 4th phase: moving the piece
						playState.setText("Game In Progress: Moving Piece 12");
					}
				}
				else if(phase==3){//If the current phase is 3: milling
					if(player==Color.BLUE){
						if(colors[12]!=Color.BLACK && colors[12]!=Color.BLUE){//Check to see if the space isn't empty or if it isn't occupied by your own piece
							colors[12]=Color.BLACK;//Remove the piece and replace it with a blank piece
							board.colors = colors;
							board.repaint();//Repaint the board with the new colors
							logic.updatePoints(colors);
							logic.redPieces--;//Decrement the number of pieces red has remaining
							if(playAI==true){
								phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
								if(phase==1){playState.setText("Game In Progress: Placing pieces");}
								else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
								AITurn();
							}
							else{
								status.setForeground(Color.RED);//Switch to the next player
								status.setText("Current player: RED");
								player = Color.RED;
								phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
								if(phase==1){playState.setText("Game In Progress: Placing pieces");}
								else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
								}	
							}
					}
					else if(player==Color.RED){
						if(colors[12]!=Color.BLACK && colors[12]!=Color.RED){//Check to see if the space isn't empty or if it isn't occupied by your own piece
							colors[12]=Color.BLACK;//Remove the piece and replace it with a blank piece
							board.colors = colors;
							board.repaint();//Repaint the board with the new colors
							logic.updatePoints(colors);
							logic.bluePieces--;//Decrement the number of pieces blue has remaining
							status.setForeground(Color.BLUE);//Switch to the next player
							status.setText("Current Player: BLUE");
							player = Color.BLUE;
							phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
							if(phase==1){playState.setText("Game In Progress: Placing pieces");}
							else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
						}
					}
				}
				else if(phase==4){//If the current phase is 4: Moving a piece
					if(logic.validMove(currentPiece, 12)){
						colors[12] = player;//Update the color arrays
						colors[currentPiece] = Color.BLACK;
						logic.updatePoints(colors);
						board.colors = colors;
						board.repaint();//Repaint the board
						if(logic.checkRow3() || logic.checkCol3()){//Check for a mill
							phase = 3;
							playState.setText("Game in Progress: Mill");
						}
						else if(playAI){
							phase = 2;
							AITurn();
						}
						else{//Switch to the next player and go back to phase 2
							if(player==Color.BLUE){
								player=Color.RED;
								status.setForeground(Color.RED);
								status.setText("Current Player: RED");
							}
							else{
								player=Color.BLUE;
								status.setForeground(Color.BLUE);
								status.setText("Current Player: BLUE");
							}
							phase = 2;
							playState.setText("Game In Progress: Moving Pieces");
						}
					}
				}
			}
			//Final row of spaces
			else if((e.getX()>=90)&&(e.getX()<=110)&&(e.getY()>=490)&&(e.getY()<=510)){
				if(phase==1){//If the current phase is 1: Placing pieces
					if(colors[13]==Color.BLACK){//Can only place pieces on blank spaces
						colors[13] = player;//Update the color array
						board.colors = colors;
						board.repaint();//Repaint the board with the new colors
						playState.setText("Game In Progress: Placing pieces");;
						//Switch to the next player and increment their respective Placed counters
						logic.addPiece(player);
						logic.updatePoints(colors);
						if(player == Color.BLUE){
							if(logic.checkRow4() || logic.checkCol1()){//If the player has formed a mill, move to the temporary 3rd phase: milling
								phase = 3;
								playState.setText("Game In Progress: Mill");
							}
							else{
								if(playAI==true){
									phase = logic.checkPhase();
									if(phase==2){
										playState.setText("Game In Progress: Moving Pieces");
									}
									AITurn();
								}
								else{
									status.setForeground(Color.RED);
									status.setText("Current player: RED");
									player = Color.RED;
									phase = logic.checkPhase();
									if(phase==2){
										playState.setText("Game In Progress: Moving Pieces");
									}
								}
							}
						}
						else{
							if(logic.checkRow4() || logic.checkCol1()){//If the player has formed a mill, move to the temporary 3rd phase: milling
								phase = 3;
								playState.setText("Game In Progress: Mill");
							}
							else{//If the player hasn't formed a mill, then go to the next player's turn
								status.setForeground(Color.BLUE);
								status.setText("Current Player: BLUE");
								player = Color.BLUE;
								phase = logic.checkPhase();
								if(phase==2){
									playState.setText("Game In Progress: Moving Pieces");
								}
							}	
						}
					}
				}
				else if(phase==0){//If the current phase is 0: Setting up a game in progress
					colors[13] = player;//Update the color array
					board.colors = colors;
					board.repaint();//Repaint the board with the new colors
					playState.setText("");
				}
				else if(phase==2){//If the current phase is 2: Choosing pieces to move
					if(player==Color.BLUE && colors[13]==Color.BLUE && logic.isMoveable(13)){//If the current player selects their own piece
						currentPiece = 13;//Update the current piece being moved
						phase = 4;//Move to the temporary 4th phase: moving the piece
						playState.setText("Game In Progress: Moving Piece 13");
					}
					else if(player==Color.RED && colors[13]==Color.RED && logic.isMoveable(13)){//If the current player selects their own piece
						currentPiece = 13;//Update the current piece being moved
						phase = 4;//Move to the temporary 4th phase: moving the piece
						playState.setText("Game In Progress: Moving Piece 13");
					}
				}
				else if(phase==3){//If the current phase is 3: milling
					if(player==Color.BLUE){
						if(colors[13]!=Color.BLACK && colors[13]!=Color.BLUE){//Check to see if the space isn't empty or if it isn't occupied by your own piece
							colors[13]=Color.BLACK;//Remove the piece and replace it with a blank piece
							board.colors = colors;
							board.repaint();//Repaint the board with the new colors
							logic.updatePoints(colors);
							logic.redPieces--;//Decrement the number of pieces red has remaining
							if(playAI==true){
								phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
								if(phase==1){playState.setText("Game In Progress: Placing pieces");}
								else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
								AITurn();
							}
							else{
								status.setForeground(Color.RED);//Switch to the next player
								status.setText("Current player: RED");
								player = Color.RED;
								phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
								if(phase==1){playState.setText("Game In Progress: Placing pieces");}
								else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
								}	
							}
					}
					else if(player==Color.RED){
						if(colors[13]!=Color.BLACK && colors[13]!=Color.RED){//Check to see if the space isn't empty or if it isn't occupied by your own piece
							colors[13]=Color.BLACK;//Remove the piece and replace it with a blank piece
							board.colors = colors;
							board.repaint();//Repaint the board with the new colors
							logic.updatePoints(colors);
							logic.bluePieces--;//Decrement the number of pieces blue has remaining
							status.setForeground(Color.BLUE);//Switch to the next player
							status.setText("Current Player: BLUE");
							player = Color.BLUE;
							phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
							if(phase==1){playState.setText("Game In Progress: Placing pieces");}
							else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
						}
					}
				}
				else if(phase==4){//If the current phase is 4: Moving a piece
					if(logic.validMove(currentPiece, 13)){
						colors[13] = player;//Update the color arrays
						colors[currentPiece] = Color.BLACK;
						logic.updatePoints(colors);
						board.colors = colors;
						board.repaint();//Repaint the board
						if(logic.checkRow4() || logic.checkCol1()){//Check for a mill
							phase = 3;
							playState.setText("Game in Progress: Mill");
						}
						else if(playAI){
							phase = 2;
							AITurn();
						}
						else{//Switch to the next player and go back to phase 2
							if(player==Color.BLUE){
								player=Color.RED;
								status.setForeground(Color.RED);
								status.setText("Current Player: RED");
							}
							else{
								player=Color.BLUE;
								status.setForeground(Color.BLUE);
								status.setText("Current Player: BLUE");
							}
							phase = 2;
							playState.setText("Game In Progress: Moving Pieces");
						}
					}
				}
			}
			else if((e.getX()>=290)&&(e.getX()<=310)&&(e.getY()>=490)&&(e.getY()<=510)){
				if(phase==1){//If the current phase is 1: Placing pieces
					if(colors[14]==Color.BLACK){//Can only place pieces on blank spaces
						colors[14] = player;//Update the color array
						board.colors = colors;
						board.repaint();//Repaint the board with the new colors
						playState.setText("Game In Progress: Placing pieces");
						//Switch to the next player and increment their respective Placed counters
						logic.addPiece(player);
						logic.updatePoints(colors);
						if(player == Color.BLUE){
							if(logic.checkRow4()){//If the player has formed a mill, move to the temporary 3rd phase: milling
								phase = 3;
								playState.setText("Game In Progress: Mill");
							}
							else{
								if(playAI==true){
									phase = logic.checkPhase();
									if(phase==2){
										playState.setText("Game In Progress: Moving Pieces");
									}
									AITurn();
								}
								else{
									status.setForeground(Color.RED);
									status.setText("Current player: RED");
									player = Color.RED;
									phase = logic.checkPhase();
									if(phase==2){
										playState.setText("Game In Progress: Moving Pieces");
									}
								}
							}
						}
						else{
							if(logic.checkRow4()){//If the player has formed a mill, move to the temporary 3rd phase: milling
								phase = 3;
								playState.setText("Game In Progress: Mill");
							}
							else{//If the player hasn't formed a mill, then go to the next player's turn
								status.setForeground(Color.BLUE);
								status.setText("Current Player: BLUE");
								player = Color.BLUE;
								phase = logic.checkPhase();
								if(phase==2){
									playState.setText("Game In Progress: Moving Pieces");
								}
							}	
						}
					}
				}
				else if(phase==0){//If the current phase is 0: Setting up a game in progress
					colors[14] = player;//Update the color array
					board.colors = colors;
					board.repaint();//Repaint the board with the new colors
					playState.setText("");
				}
				else if(phase==2){//If the current phase is 2: Choosing pieces to move
					if(player==Color.BLUE && colors[14]==Color.BLUE && logic.isMoveable(14)){//If the current player selects their own piece
						currentPiece = 14;//Update the current piece being moved
						phase = 4;//Move to the temporary 4th phase: moving the piece
						playState.setText("Game In Progress: Moving Piece 14");
					}
					else if(player==Color.RED && colors[14]==Color.RED && logic.isMoveable(14)){//If the current player selects their own piece
						currentPiece = 14;//Update the current piece being moved
						phase = 4;//Move to the temporary 4th phase: moving the piece
						playState.setText("Game In Progress: Moving Piece 14");
					}
				}
				else if(phase==3){//If the current phase is 3: milling
					if(player==Color.BLUE){
						if(colors[14]!=Color.BLACK && colors[14]!=Color.BLUE){//Check to see if the space isn't empty or if it isn't occupied by your own piece
							colors[14]=Color.BLACK;//Remove the piece and replace it with a blank piece
							board.colors = colors;
							board.repaint();//Repaint the board with the new colors
							logic.updatePoints(colors);
							logic.redPieces--;//Decrement the number of pieces red has remaining
							if(playAI==true){
								phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
								if(phase==1){playState.setText("Game In Progress: Placing pieces");}
								else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
								AITurn();
							}
							else{
								status.setForeground(Color.RED);//Switch to the next player
								status.setText("Current player: RED");
								player = Color.RED;
								phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
								if(phase==1){playState.setText("Game In Progress: Placing pieces");}
								else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
								}	
							}
					}
					else if(player==Color.RED){
						if(colors[14]!=Color.BLACK && colors[14]!=Color.RED){//Check to see if the space isn't empty or if it isn't occupied by your own piece
							colors[14]=Color.BLACK;//Remove the piece and replace it with a blank piece
							board.colors = colors;
							board.repaint();//Repaint the board with the new colors
							logic.updatePoints(colors);
							logic.bluePieces--;//Decrement the number of pieces blue has remaining
							status.setForeground(Color.BLUE);//Switch to the next player
							status.setText("Current Player: BLUE");
							player = Color.BLUE;
							phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
							if(phase==1){playState.setText("Game In Progress: Placing pieces");}
							else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
						}
					}
				}
				else if(phase==4){//If the current phase is 4: Moving a piece
					if(logic.validMove(currentPiece, 14)){
						colors[14] = player;//Update the color arrays
						colors[currentPiece] = Color.BLACK;
						logic.updatePoints(colors);
						board.colors = colors;
						board.repaint();//Repaint the board
						if(logic.checkRow4()){//Check for a mill
							phase = 3;
							playState.setText("Game in Progress: Mill");
						}
						else if(playAI){
							phase = 2;
							AITurn();
						}
						else{//Switch to the next player and go back to phase 2
							if(player==Color.BLUE){
								player=Color.RED;
								status.setForeground(Color.RED);
								status.setText("Current Player: RED");
							}
							else{
								player=Color.BLUE;
								status.setForeground(Color.BLUE);
								status.setText("Current Player: BLUE");
							}
							phase = 2;
							playState.setText("Game In Progress: Moving Pieces");
						}
					}
				}
			}
			else if((e.getX()>=490)&&(e.getX()<=510)&&(e.getY()>=490)&&(e.getY()<=510)){
				if(phase==1){//If the current phase is 1: Placing pieces
					if(colors[15]==Color.BLACK){//Can only place pieces on blank spaces
						colors[15] = player;//Update the color array
						board.colors = colors;
						board.repaint();//Repaint the board with the new colors
						playState.setText("Game In Progress: Placing pieces");
						//Switch to the next player and increment their respective Placed counters
						logic.addPiece(player);
						logic.updatePoints(colors);
						if(player == Color.BLUE){
							if(logic.checkRow4() || logic.checkCol4()){//If the player has formed a mill, move to the temporary 3rd phase: milling
								phase = 3;
								playState.setText("Game In Progress: Mill");
							}
							else{
								if(playAI==true){
									phase = logic.checkPhase();
									if(phase==2){
										playState.setText("Game In Progress: Moving Pieces");
									}
									AITurn();
								}
								else{
									status.setForeground(Color.RED);
									status.setText("Current player: RED");
									player = Color.RED;
									phase = logic.checkPhase();
									if(phase==2){
										playState.setText("Game In Progress: Moving Pieces");
									}
								}
							}
						}
						else{
							if(logic.checkRow4() || logic.checkCol4()){//If the player has formed a mill, move to the temporary 3rd phase: milling
								phase = 3;
								playState.setText("Game In Progress: Mill");
							}
							else{//If the player hasn't formed a mill, then go to the next player's turn
								status.setForeground(Color.BLUE);
								status.setText("Current Player: BLUE");
								player = Color.BLUE;
								phase = logic.checkPhase();
								if(phase==2){
									playState.setText("Game In Progress: Moving Pieces");
								}
							}	
						}
					}
				}
				else if(phase==0){//If the current phase is 0: Setting up a game in progress
					colors[15] = player;//Update the color array
					board.colors = colors;
					board.repaint();//Repaint the board with the new colors
					playState.setText("");
				}
				else if(phase==2){//If the current phase is 2: Choosing pieces to move
					if(player==Color.BLUE && colors[15]==Color.BLUE && logic.isMoveable(15)){//If the current player selects their own piece
						currentPiece = 15;//Update the current piece being moved
						phase = 4;//Move to the temporary 4th phase: moving the piece
						playState.setText("Game In Progress: Moving Piece 15");
					}
					else if(player==Color.RED && colors[15]==Color.RED && logic.isMoveable(15)){//If the current player selects their own piece
						currentPiece = 15;//Update the current piece being moved
						phase = 4;//Move to the temporary 4th phase: moving the piece
						playState.setText("Game In Progress: Moving Piece 15");
					}
				}
				else if(phase==3){//If the current phase is 3: milling
					if(player==Color.BLUE){
						if(colors[15]!=Color.BLACK && colors[15]!=Color.BLUE){//Check to see if the space isn't empty or if it isn't occupied by your own piece
							colors[15]=Color.BLACK;//Remove the piece and replace it with a blank piece
							board.colors = colors;
							board.repaint();//Repaint the board with the new colors
							logic.updatePoints(colors);
							logic.redPieces--;//Decrement the number of pieces red has remaining
							if(playAI==true){
								phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
								if(phase==1){playState.setText("Game In Progress: Placing pieces");}
								else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
								AITurn();
							}
							else{
								status.setForeground(Color.RED);//Switch to the next player
								status.setText("Current player: RED");
								player = Color.RED;
								phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
								if(phase==1){playState.setText("Game In Progress: Placing pieces");}
								else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
								}	
							}
					}
					else if(player==Color.RED){
						if(colors[15]!=Color.BLACK && colors[15]!=Color.RED){//Check to see if the space isn't empty or if it isn't occupied by your own piece
							colors[15]=Color.BLACK;//Remove the piece and replace it with a blank piece
							board.colors = colors;
							board.repaint();//Repaint the board with the new colors
							logic.updatePoints(colors);
							logic.bluePieces--;//Decrement the number of pieces blue has remaining
							status.setForeground(Color.BLUE);//Switch to the next player
							status.setText("Current Player: BLUE");
							player = Color.BLUE;
							phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
							if(phase==1){playState.setText("Game In Progress: Placing pieces");}
							else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
						}
					}
				}
				else if(phase==4){//If the current phase is 4: Moving a piece
					if(logic.validMove(currentPiece, 15)){
						colors[15] = player;//Update the color arrays
						colors[currentPiece] = Color.BLACK;
						logic.updatePoints(colors);
						board.colors = colors;
						board.repaint();//Repaint the board
						if(logic.checkRow4() || logic.checkCol4()){//Check for a mill
							phase = 3;
							playState.setText("Game in Progress: Mill");
						}
						else if(playAI){
							phase = 2;
							AITurn();
						}
						else{//Switch to the next player and go back to phase 2
							if(player==Color.BLUE){
								player=Color.RED;
								status.setForeground(Color.RED);
								status.setText("Current Player: RED");
							}
							else{
								player=Color.BLUE;
								status.setForeground(Color.BLUE);
								status.setText("Current Player: BLUE");
							}
							phase = 2;
							playState.setText("Game In Progress: Moving Pieces");
						}
					}
				}
			}
			else{
				playState.setText("Invalid Position");
			}
			updateScores();
		}

		@Override
		public void mouseDragged(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseMoved(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void actionPerformed(ActionEvent e) {//Method that listens for button presses
			if(e.getSource()==newGame){//When the user presses the new game button, reset the board and randomly choose a player
				for(int i=0; i<16; i++){
					colors[i] = Color.BLACK;
				}
				board.colors = colors;
				board.repaint();
				status.setText("");
				playGame = true;
				playState.setText("Game In Progress: Placing pieces");
				choosePlayer();
				phase = 1;
				start.setEnabled(false);
				newGameAI.setEnabled(false);
				logic.resetPlaced();
				updateScores();
			}
			else if(e.getSource()==newGameAI){//When the user wants to start a new game against the AI, reset the board and set playAI to true
				for(int i=0; i<16; i++){
					colors[i] = Color.BLACK;
				}
				playAI = true;
				board.colors = colors;
				board.repaint();
				status.setText("");
				playGame = true;
				playState.setText("Game In Progress: Placing pieces");
				player = Color.BLUE;
				aiColor = Color.RED;
				phase = 1;
				start.setEnabled(false);
				newGame.setEnabled(false);
				logic.resetPlaced();
				updateScores();
			}
			else if(e.getSource()==start){//If the user clicks the start button, validate the current board and notify the user if it's invalid
				logic.updatePoints(colors);
				logic.countPoints();
				if(logic.isValid()==true){//If the board is valid, start at the moving phase
					playState.setText("The current board is valid");
					updateScores();
					phase = 2;
					playGame = true;
					logic.setPlaced(6, 6);//Set the pieces placed to 6 so phases work properly
					choosePlayer();
				}
				else{
					playState.setText("The current board is invalid");
				}
			}
			else if(e.getSource()==startAI){//The user clicks this button when they want to start a pre-existing game against the AI
				logic.updatePoints(colors);
				logic.countPoints();
				if(logic.isValid()==true){//If the board is valid, start at the moving phase
					playState.setText("The current board is valid");
					updateScores();
					phase = 2;
					playGame = true;
					player = Color.BLUE;
					playAI = true;
					logic.setPlaced(6, 6);//Set the pieces placed to 6 so phases work properly
					int x = new Random().nextInt(2);
					if(x==0){
						status.setForeground(Color.BLUE);
						status.setText("Player's Turn");
					}
					else{
						AITurn();
					}
				}
				else{
					playState.setText("The current board is invalid");
				}
			}
			//If the user clicks the save button, save the current state of the board to a text file
			else if(e.getSource()==save){
				try{
					BufferedWriter w = new BufferedWriter(new FileWriter("saved.txt"));
					for(int i=0; i<16; i++){
						if(i==15){
							if(colors[i]==Color.BLACK){w.write(1);}
							else if(colors[i]==Color.BLUE){w.write(2);}
							else if(colors[i]==Color.RED){w.write(3);}
							}
						else{
							if(colors[i]==Color.BLACK){w.write(1+",");}
							else if(colors[i]==Color.BLUE){w.write(2+",");}
							else if(colors[i]==Color.RED){w.write(3+",");}
						}	
						
					}
					w.close();
				}
				catch(IOException ex){
			
				}				
			}
			else if(e.getSource()==load){
				try{
					FileReader fr = new FileReader("saved.txt");
					BufferedReader br = new BufferedReader(fr);
					String stringRead = br.readLine();
					br.close();
					String[] read = stringRead.split(",");
					for(int i=0; i<16; i++){
						if(read[i].equals("2")){colors[i]=Color.BLUE;}
						else if(read[i].equals("3")){colors[i]=Color.RED;}
					}
					board.colors = colors;
					board.repaint();
					phase = 2;
					logic.setPlaced(6, 6);
					logic.updatePoints(colors);
					
				}
				catch(IOException ex){
			}
		}
	}
	//Method that is used whenever that AI has to make a move
	private static void AITurn(){
		status.setForeground(Color.RED);
		status.setText("AI is moving");
		if(phase==1){//If the current phase is 1: placing pieces
			int x = ai.placePiece(colors);
			colors[x] = aiColor;
			board.repaint();
			logic.addPiece(aiColor);
			logic.updatePoints(colors);
			AIMill(x);//Check if the AI has performed a mill
			phase = logic.checkPhase();
			if(phase==2){
				playState.setText("Game In Progress: Moving Pieces");
			}
		}
		else if(phase==2){//If the current phase is 2: moving pieces
			int x = ai.pickPiece(colors, Color.RED, logic);
			int y = ai.movePiece(colors, Color.RED, logic, x);
			colors[x] = Color.BLACK;
			colors[y] = Color.RED;
			logic.updatePoints(colors);
			board.colors = colors;
			board.repaint();//Repaint the board
			AIMill(y);
		}
		else if(phase==3){//If the current phase is 3: milling
			int x = ai.removePiece(colors, Color.BLUE);
			colors[x] = Color.BLACK;
			board.colors = colors;
			board.repaint();//Repaint the board with the new colors
			logic.updatePoints(colors);
			logic.bluePieces--;//Decrement the number of pieces blue has remaining
			phase = logic.checkPhase();//Switch back to the appropriate phase (1 or 2)
			if(phase==1){playState.setText("Game In Progress: Placing pieces");}
			else if(phase==2){playState.setText("Game In Progress: Moving Pieces");updateScores();}
		}
		status.setForeground(Color.BLUE);
		status.setText("Player's Turn");
	}
	//This method is used whenever the AI places or moves a piece
	//It checks the row/column corresponding to where they placed their piece for a mill
	private static void AIMill(int x){
		if(x==0 && (logic.checkRow1()||logic.checkCol1())){
			phase = 3;
			AITurn();
		}
		else if(x==1 && logic.checkRow1()){
			phase = 3;
			AITurn();
		}
		else if(x==2 && (logic.checkRow1()||logic.checkCol4())){
			phase = 3;
			AITurn();
		}
		else if(x==3 && (logic.checkRow2()||logic.checkCol2())){
			phase = 3;
			AITurn();
		}
		else if(x==4 && logic.checkRow2()){
			phase = 3;
			AITurn();
		}
		else if(x==5 && (logic.checkRow2()||logic.checkCol3())){
			phase = 3;
			AITurn();
		}
		else if(x==6 && (logic.checkCol1())){
			phase = 3;
			AITurn();
		}
		else if(x==7 && (logic.checkCol2())){
			phase = 3;
			AITurn();
		}
		else if(x==8 && (logic.checkCol3())){
			phase = 3;
			AITurn();
		}
		else if(x==9 && (logic.checkCol4())){
			phase = 3;
			AITurn();
		}
		else if(x==10 && (logic.checkCol2()||logic.checkRow3())){
			phase = 3;
			AITurn();
		}
		else if(x==11 && (logic.checkRow3())){
			phase = 3;
			AITurn();
		}
		else if(x==12 && (logic.checkCol3()||logic.checkRow3())){
			phase = 3;
			AITurn();
		}
		else if(x==13 && (logic.checkCol1()||logic.checkRow4())){
			phase = 3;
			AITurn();
		}
		else if(x==14 && (logic.checkRow4())){
			phase = 3;
			AITurn();
		}
		else if(x==15 && (logic.checkCol4()||logic.checkRow4())){
			phase = 3;
			AITurn();
		}
	}
	//Method that updates the score labels and checks to see if a player has won
	private static void updateScores(){
		logic.countPoints();
		blueScore.setText("Blue Score: "+logic.getBlue());
		redScore.setText("Red Score: "+logic.getRed());
		if(phase==2){//Make sure all 6 pieces have been placed before checking for a winner
			if(logic.getRed()<=2){//If red has 2 remaining pieces after a mill, then blue wins
				phase = 0;
				playState.setForeground(Color.BLUE);
				playState.setText("Blue Wins!");
			}
			else if(logic.getBlue()<=2){//If blue has 2 remaining pieces after a mill, then red wins
				phase = 0;
				playState.setForeground(Color.RED);
				playState.setText("Red Wins!");
			}
		}
		
	}
	//Method that decides which player goes first
	private static void choosePlayer(){
		int x = new Random().nextInt(2);
		if(x == 0){
			player = Color.BLUE;
			status.setForeground(Color.BLUE);
			status.setText("Current Player: BLUE");
		}
		else{
			player = Color.RED;
			status.setForeground(Color.RED);
			status.setText("Current Player: RED");
		}
	}
	  

	

	}	
}
